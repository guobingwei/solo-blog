title: 分享-WEB前端安全
date: '2020-08-13 06:53:05'
updated: '2020-08-13 06:54:04'
tags: [安全]
permalink: /articles/2020/08/13/1597272785233.html
---
# 浏览器的同源策略

1995年，同源政策由 Netscape 公司引入浏览器。目前，所有浏览器都实行这个政策。

最初，它的含义是指，A网页设置的 Cookie，B网页不能打开，除非这两个网页"同源"。所谓"同源"指的是"三个相同"。

* 协议相同
* 域名相同
* 端口相同

举例来说，[`http://www.example.com/dir/page.html`](http://www.example.com/dir/page.html "http://www.example.com/dir/page.html")这个网址，协议是`http://`，域名是[`www.example.com`](http://www.example.com/ "www.example.com")，端口是`80`（默认端口可以省略）。它的同源情况如下。

* [`http://www.example.com/dir2/other.html`](http://www.example.com/dir2/other.html "http://www.example.com/dir2/other.html")：同源
* [`http://example.com/dir/other.html`](http://example.com/dir/other.html "http://example.com/dir/other.html")：不同源（域名不同）
* [`http://v2.www.example.com/dir/other.html`](http://v2.www.example.com/dir/other.html "http://v2.www.example.com/dir/other.html")：不同源（域名不同）
* [`http://www.example.com:81/dir/other.html`](http://www.example.com:81/dir/other.html "http://www.example.com:81/dir/other.html")：不同源（端口不同）

目的：同源政策的目的，是为了保证用户信息的安全，防止恶意的网站窃取数据。

### 限制范围

> （1） Cookie、LocalStorage 和 IndexDB 无法读取。
>
> （2） DOM 无法获得。
>
> （3） AJAX 请求不能发送。

ajax跨域解决办法

同源政策规定，AJAX请求只能发给同源的网址

解决办法：

* JSONP
* WebSocket
* CORS 跨源资源分享（Cross-Origin Resource Sharing）

同源策略阮一峰的博客：[http://www.ruanyifeng.com/blog/2016/04/same-origin-policy.html](http://www.ruanyifeng.com/blog/2016/04/same-origin-policy.html "http://www.ruanyifeng.com/blog/2016/04/same-origin-policy.html")

# 一、XSS

## 1.1、概述

XSS(cross Site Scripting)，即跨站脚本。发生在目标网站中目标用户的浏览器层面上，当用户浏览器渲染整个HTML文档的过程中出现了不被预期的脚本指令并执行，XSS就会发生。

强调三点：

1. 目标网站的目标用户
2. 浏览器（同源策略）
3. 不被预期

## 1.2、反射性XSS

发出请求时，XSS代码出现在URL中，作为输入提交到服务器，服务器解析后响应，响应内容中出现这段XSS代码，最后浏览器解析执行，这个过程就像是一次反射，故称为反射性XSS。

攻击的时候黑客会采取的第一个步骤是在 目标网站上找出一个 XSS 漏洞，然后构造一个特制的 URL，也被称为链接。要做到这一点，黑客会搜寻网站上的客户端提供的数 据可以被发送到 Web 服务器，然后回显到屏幕上的任何功能，比如搜索框。

示例代码：

代码块

Plain Text

```
<?php
```

```
if(!array_key_exists ("name", $_GET) || $_GET['name'] == NULL || $_GET['name'] == ''){
```

```
 $isempty = true;
```

```
} else {
```

```
 echo '<pre>';
```

```
 echo 'Hello ' . $_GET['name'];
```

```
 echo '</pre>';
```

```
}
```

```
?>
```

```

```

## 1.3、存储型XSS

提交的xss代码会存储在服务端，等下次请求数据浏览器渲染页面时触发执行。

代码：

代码块

Plain Text

```
<?php
```

```
if(isset($_POST['btnSign']))
```

```
{
```

```
   $message = trim($_POST['mtxMessage']);
```

```
   $name    = trim($_POST['txtName']);
```

```
   // Sanitize message input
```

```
   $message = stripslashes($message);
```

```
   $message = mysql_real_escape_string($message);
```

```
   // Sanitize name input
```

```
   $name = mysql_real_escape_string($name);
```

```
   $query = "INSERT INTO guestbook (comment,name) VALUES ('$message','$name');";
```

```
   $result = mysql_query($query) or die('<pre>' . mysql_error() . '</pre>' );
```

```
}
```

```
?>
```

```

```

## 1.4、DOM XSS

DOM XSS 的xss代码并不需要服务器解析响应的直接参与、触发xss就是靠浏览器的dom解析，可以认为完全是客户端的事情。

代码块

Plain Text

```
<script>
```

```
eval(location.hash.substr(1));
```

```
</script>
```

触发方式为：[http://www.foo.com/xssme.html#alert(1)](http://www.foo.com/xssme.html#alert(1)) "http://www.foo.com/xssme.html#alert(1)")

## 1.5、出现场景及其危害

* 盗取用户cookie
* 钓鱼
* 编写xss代码，恶意篡改数据，删除目标文章

# 二、CSRF

## 2.1、概述

CSRF（Cross site Request Forgery）跨站请求伪造。

CSRF 攻击迫使终端用户在通过验证后在 web 应用中执行不必要的操作。在社会工程帮助下(如通过电子邮件/聊天发送的链接),攻击者可能会迫使 Web 应用程序用户执行攻 击者所选择的行动。

![](https://km.sankuai.com/api/file/64211568/64211471)

漏洞影响:

当一个成功的 CSRF 漏洞的目标是普通用户时,它能够危害终端用户的数据和操作。 但如果最终的目标用户是管理员帐户,一个 CSRF 攻击可以损害整个 Web 应用程序。

代码块

Plain Text

```
<?php
```

```
    if (isset($_GET['Change'])) {
```

```
        // Turn requests into variables
```

```
        $pass_new = $_GET['password_new'];
```

```
        $pass_conf = $_GET['password_conf'];
```

```
        if (($pass_new == $pass_conf)){
```

```
            $pass_new = mysql_real_escape_string($pass_new);
```

```
            $pass_new = md5($pass_new);
```

```
            $insert="UPDATE `users` SET password = '$pass_new' WHERE user = 'admin';";
```

```
            $result=mysql_query($insert) or die('<pre>' . mysql_error() . '</pre>' );
```

```
            echo "<pre> Password Changed </pre>";    
```

```
            mysql_close();
```

```
        }
```

```
        else{    
```

```
            echo "<pre> Passwords did not match. </pre>";        
```

```
        }
```

```
    }
```

```
?>
```

CSRF攻击是源于WEB的隐式身份验证机制！WEB的身份验证机制虽然可以保证一个请求是来自于某个用户的浏览器，但却无法保证该请求是用户批准发送的！

# 三、界面操作劫持

## 3.1、界面操作劫持

界面操作劫持是一种基于视觉欺骗的Web会话劫持攻击。它通过在网页的可见输入控件上覆盖一个不可见的框（iframe），使得用户误以为在操作可见控件。而实际用户的行为被不可见的框所劫持，从而在用户不知情的情况下窃取敏感信息，篡改数据。主要分为三种：

* 点击劫持（ClickJacking）
* 拖放劫持（Drag&Drop jacking）
* 触屏劫持（Tapjacking）

## 3.2、界面操作劫持技术原理分析

透明层+iframe

前面提到过【界面操作劫持是在网页的可输入控件上覆盖一个不可见的框】，覆盖指的是控件位置之间的层级关系，不可见指的是页面的透明度为0，而框指的是iframe标签。

1. 透明层使用css样式实现

IE浏览器css透明属性：

代码块

Plain Text

```
.opacity{
```

```
    background:#000;
```

```
    filter: alpha(opacity=30); // 数值从0 到 100，数值越小，透明度越高
```

```
}
```

chrome、Safari、Firefox浏览器的css透明属性如下：

代码块

Plain Text

```
opacity:0.3;  // 数值从0到1，数值越小透明度越高
```

控件之间的层级关系用z-index，而且任何浏览器都支持。

2. 使用iframe嵌入被劫持的页面

代码块

Plain Text

```
<iframe id = ""victim src = "http://www.victim.com" scrolling = "on">
```

##
3.3、点击劫持技术的实现

clickjacking.html代码如下：

代码块

Plain Text

```
<style>
```

```
# click {
```

```
  width:100px;
```

```
  top:20px;
```

```
  left:20px;
```

```
  position:absolute;
```

```
z-index : 1
```

```
}
```

```
 
```

```
# hidden {
```

```
  height:50px;
```

```
  width:120px;
```

```
  position:absolute;
```

```
  filter:alpha(opacity = 50)
```

```
opacity:0.5;
```

```
z-index=2
```

```
}
```

```
</style>
```

```
<input id = "click" value = "Click me" type = "button"/>
```

```
<iframe id = "hidden" src = "inner.html" scrolling = "on"></iframe>
```

嵌入的inner.html代码如下：

代码块

Plain Text

```
<input type = "width: 100px;" value = "Login" type = "button" onclick = "alert('test')"/>
```

# 四、漏洞挖掘

## 步骤一 发起探子请求

在真正的payload攻击请求之前，我们发出一次无危害（不包含任何特殊符号）的探子请求，此请求不会被网站的过滤机制发现，就像一次正常的请求。

“探子”的目的有以下两个：

* 探寻目标参数值是否会出现在响应上。如果不出现，就完全没有必要进行后续的payload请求和分析，因为这些payload请求与分析可能会进行很多次，浪费请求资源。
* 探寻目标参数值出现在HTML的哪个部分。不同的HTML部分对待XSS的机制是不一样的，请求的payload当然也不一样。

一般情况下，我们够着的探子请求是一个8位左右的随机字符串，且不与响应的HTML中已经存在的字符串重复。

## 步骤二 查看源码

在我们输入了探子请求之后，我们就要思考一个问题：我们输入的探子请求输出在哪里？

这时候，我们唯一的办法就是查看网页的源代码，查找探子请求的位置。

这也是为啥我们之前构造探子请求的时候要保证其唯一性，就是为了便于我们的查找。

探子请求输出的位置可能有一下几种可能：

* HTML标签之间。例如：`<div id = "body">【输出】</ div>`
* HTML标签之内。例如：`<input type = "text" value = "【输出】"></ input>`
* 成为javascript代码的值。例如：`<script>a = "【输出】";</ script>`
* 成为CSS代码的值。例如：`< style>body{font-size:【输出】px;}</ style>`

## 步骤三 构造payload

这里我们假设浏览器没有任何的过滤机制。

针对步骤二的四种可能，我们可以分别构造不同的payload。

### Part 1 HTML标签之间

#### 情形一：

如果输出点位置出现在`<div id = "body">【输出】</div>`中，那么我们直接构造`<script>alert(1)</script>`提交，即能让浏览器实现弹窗。

#### 情形二：

如果输入点出现在如下几个标签的位置：

![](http://img.blog.csdn.net/20161108202918890)

那么，我们构造的`<script>alert(1)</script>`并不能让浏览器实现弹窗。

这个时候，我们构造payload的关键在于**闭合标签（核心思想）**。

例如，我们可以构造如下的payload：`</title><script>alert(1)</script>`，这样，即能保证浏览器实现弹窗。

### Part 2 HTML标签之内

对于输出点出现在HTML标签之内的情况：`<input type = "text" value = "【输出】"></input>`。

我们有以下两种方法触发XSS：

* **闭合属性**。构造payload：” onmouseover=alert(1) x=”，使用on事件来触发脚本。
* **闭合标签和属性**。构造payload：`"><script>alert(1)</script>`，直接执行脚本。

### Part 3 成为javascript代码的值

对于我们输入的请求成为[JavaScript](http://lib.csdn.net/base/javascript "JavaScript知识库")代码的值的情况：

代码块

Plain Text

```
<script>a = "【输出】";</script>
```

我们可以构造如下的payload：

代码块

Plain Text

```
</script><script>alert(1);
```

<pre>其中，前面的<code></script></code><span>直接闭合了之前的</span><code><script></code><span>标签，后面的//是</span><a title="JavaScript知识库" href="http://lib.csdn.net/base/javascript" spellcheck="false" rel="noopener" class="ct-link" target="_blank">javascript</a><span>的注释，保证了javascript语法的正确性。这样即能触发XSS。</span></pre>

# span

web安全漏洞测试平台


| dvwa | webGoat（OWASP旗下） |
| - | - |
| [Web漏洞实战教程DVWA的使用.pdf](https://km.sankuai.com/api/file/attachment/64211568/64182602 "Web漏洞实战教程DVWA的使用.pdf") | [WebGoat安装手册.pdf](https://km.sankuai.com/api/file/attachment/64211568/64182601 "WebGoat安装手册.pdf")[WebGoat中文手册.pdf](https://km.sankuai.com/api/file/attachment/64211568/64211474 "WebGoat中文手册.pdf") |

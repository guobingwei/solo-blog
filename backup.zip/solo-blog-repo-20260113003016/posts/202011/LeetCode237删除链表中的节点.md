title: LeetCode-237-删除链表中的节点
date: '2020-11-08 00:21:46'
updated: '2020-11-08 00:21:46'
tags: [LeetCode, 链表]
permalink: /articles/2020/11/08/1604766106712.html
---
![](https://b3logfile.com/bing/20190312.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 题目描述

请编写一个函数，使其可以删除某个链表中给定的（非末尾）节点。传入函数的唯一参数为 **要被删除的节点** 。

### 解法

```
public void deleteNode(ListNode node) {
        node.val = node.next.val;
        node.next = node.next.next;
}
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-bb703d5b.png)
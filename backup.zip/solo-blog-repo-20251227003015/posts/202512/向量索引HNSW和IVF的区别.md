title: 向量索引HNSW和IVF的区别
date: '2025-12-23 22:27:26'
updated: '2025-12-23 22:27:26'
tags: [大模型]
permalink: /articles/2025/12/23/1766500046848.html
---
![](ne)

相同点：都是近似最近邻（ANN）索引。

**HNSW**（Hierarchical Navigable Small World）原理：构建多层小世界图，顶层点少、底层点多；查询从顶层开始以贪心/束搜索逐层向下，快速逼近最近邻。优点：召回高、查询快；缺点：建索引内存/时间较高。

![image.png](https://b3logfile.com/file/2025/12/image-311HIBK.png)

**IVF**（Inverted File，倒排列表聚类索引）原理与对比简述：

原理：先用聚类（常见 k-means）把向量空间分成 n 个簇（centroids），建立“倒排表”。检索时先用查询向量找最相近的几个簇（probe 数量 nprobe），只在这些簇的倒排链里做精排（可选用 PQ/OPQ 压缩再粗排+精排）。

![image.png](https://b3logfile.com/file/2025/12/image-IH9tXxH.png)

* **优点：**
  * 搜索可控：通过 nprobe 调节“访问簇数→召回/延迟”。
  * 内存友好：可配合 PQ/OPQ 做向量压缩，减少内存/存储。
  * 训练/构建相对简单，易并行；适合大规模批量索引。
* **缺点：**
  * 召回依赖聚类质量，簇边界附近的样本可能漏检；需要调 nlist/nprobe。
  * 对数据分布敏感，长尾或非均匀分布时簇会倾斜，需再平衡或多级 IVF。
  * 多次量化/压缩会损失精度，若不精排可能影响召回。

与 HNSW 对比：* 召回与精度：HNSW 通常更高召回/更稳（图结构贪心搜索）；IVF 召回更依赖 nprobe 及聚类质量。

* 查询延迟：HNSW 查询速度通常很快且稳定；IVF 可通过调低 nprobe 获得更低延迟，但可能掉召回。
* 构建成本：HNSW **建索引耗内存/时间较高**；IVF 构建更轻量，支持批量离线训练和并行。
* 内存/存储：HNSW 索引膨胀（图邻接表）；IVF+PQ/OPQ 压缩后更省内存/磁盘。
* 参数调优：HNSW 主要是 M/efConstruction/efSearch；IVF 主要是 nlist（簇数）、nprobe（探测簇数）、以及是否用 PQ/OPQ 与编码维度。
* 适用场景：HNSW 适合低延迟、高召回、数据量中到大、内存充足的**在线检索**；IVF 适合超大规模、对存储/内存敏感，且可以接受通过 nprobe 在“延迟/召回”间折中。

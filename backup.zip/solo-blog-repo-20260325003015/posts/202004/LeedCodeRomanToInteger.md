title: LeedCode-Roman To Integer
date: '2020-04-04 16:06:54'
updated: '2020-04-04 16:06:54'
tags: [LeedCode]
permalink: /articles/2020/04/04/1585987614911.html
---
# 题目描述

```

Roman numerals are represented by seven different symbols: I, V, X, L, C, D and M.

Symbol       Value
I             1
V             5
X             10
L             50
C             100
D             500
M             1000
For example, two is written as II in Roman numeral, just two one's added together. Twelve is written as, XII, which is simply X + II. The number twenty seven is written as XXVII, which is XX + V + II.

Roman numerals are usually written largest to smallest from left to right. However, the numeral for four is not IIII. Instead, the number four is written as IV. Because the one is before the five we subtract it making four. The same principle applies to the number nine, which is written as IX. There are six instances where subtraction is used:

I can be placed before V (5) and X (10) to make 4 and 9. 
X can be placed before L (50) and C (100) to make 40 and 90. 
C can be placed before D (500) and M (1000) to make 400 and 900.
Given a roman numeral, convert it to an integer. Input is guaranteed to be within the range from 1 to 3999.

Example 1:

Input: "III"
Output: 3
Example 2:

Input: "IV"
Output: 4
Example 3:

Input: "IX"
Output: 9
Example 4:

Input: "LVIII"
Output: 58
Explanation: L = 50, V= 5, III = 3.
Example 5:

Input: "MCMXCIV"
Output: 1994
Explanation: M = 1000, CM = 900, XC = 90 and IV = 4.

```

这道题就是要把罗马数字转换为数字，但它遵循一些规则，根据题目描述，可以知道这样一个规则，如果前一个数字比后一个数字小，对应的数字需要两者相减，否则相加即可。

# 解法

这道题很多人都会用map存储 罗马字母对数字的映射，但是map的查询效率不是很高。所以把这块通过switch case来代替，效率更好

思路：循环比较相邻的两个字符对应的数字，如果当前数字比后一个小，值相减，否则相加

代码如下：

```算法代码
public static int romanToInt(String s) {
		int number = 0;
		int length = s.length();
		for (int i = 0; i < length; i++) {
			Character current = s.charAt(i);
			if (i < length -1 && getNumber(current) < getNumber(s.charAt(i+1))) {
				number -= getNumber(current);
			} else {
				number += getNumber(current);
			}
		}
		return number;
	}

	public static int getNumber(Character ch) {
		switch (ch) {
			case 'I':
				return 1;
			case 'V':
				return 5;
			case 'X':
				return 10;
			case 'L':
				return 50;
			case 'C':
				return 100;
			case 'D':
				return 500;
			case 'M':
				return 1000;
			default:
				return 0;
		}
	}
```

运行结果为：
![image.png](https://img.hacpai.com/file/2020/04/image-262180f2.png)

想想如何能优化呢？
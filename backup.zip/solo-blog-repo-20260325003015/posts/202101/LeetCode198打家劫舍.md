title: LeetCode-198-打家劫舍
date: '2021-01-07 09:50:23'
updated: '2021-01-07 09:50:23'
tags: [LeetCode, 动态规划]
permalink: /articles/2021/01/07/1609984223656.html
---
# 题目描述

```
你是一个专业的小偷，计划偷窃沿街的房屋。每间房内都藏有一定的现金，影响你偷窃的唯一制约因素就是相邻的房屋装有相互连通的防盗系统，如果两间相邻的房屋在同一晚上被小偷闯入，系统会自动报警。

给定一个代表每个房屋存放金额的非负整数数组，计算你 不触动警报装置的情况下 ，一夜之内能够偷窃到的最高金额。

 

示例 1：

输入：[1,2,3,1]
输出：4
解释：偷窃 1 号房屋 (金额 = 1) ，然后偷窃 3 号房屋 (金额 = 3)。
     偷窃到的最高金额 = 1 + 3 = 4 。
示例 2：

输入：[2,7,9,3,1]
输出：12
解释：偷窃 1 号房屋 (金额 = 2), 偷窃 3 号房屋 (金额 = 9)，接着偷窃 5 号房屋 (金额 = 1)。
     偷窃到的最高金额 = 2 + 9 + 1 = 12 。
```

# 解法

动态规划写法

```
    public int rob(int[] nums) {
        int length = nums.length;
        if (length <=0) {
            return 0;
        }
        if (length < 2) {
            return nums[length - 1];
        }
  
        int [] dp = new int[length];
        dp[0] = nums[0];
        dp[1] = Math.max(nums[0], nums[1]);
        for(int i = 2; i < nums.length; i++) {
            dp[i] = Math.max(dp[i - 2] + nums[i], dp[i - 1]);
        }
        return dp[length - 1];
    }
```



运行结果：

![image.png](https://b3logfile.com/file/2021/01/image-f5d31cb2.png)


还可以优化，记忆化递归，去掉数组节省空间

```
    public int rob(int[] nums) {
        int length = nums.length;
        if (length <=0) {
            return 0;
        }
        if (length < 2) {
            return nums[length - 1];
        }
  
        int dp1 = nums[0];
        int dp2 = Math.max(nums[0], nums[1]);
        for(int i = 2; i < length; i++) {
            int temp = dp2;
            dp2 = Math.max(dp1 + nums[i], temp);
            dp1 = temp;
        }
        return dp2;
    }
```
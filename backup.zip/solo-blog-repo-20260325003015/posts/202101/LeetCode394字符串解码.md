title: LeetCode-394-字符串解码
date: '2021-01-02 12:03:51'
updated: '2021-01-02 12:03:51'
tags: [待分类]
permalink: /articles/2021/01/02/1609560231098.html
---
![](https://b3logfile.com/bing/20201229.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

题目描述

```
给定一个经过编码的字符串，返回它解码后的字符串。

编码规则为: k[encoded_string]，表示其中方括号内部的 encoded_string 正好重复 k 次。注意 k 保证为正整数。

你可以认为输入字符串总是有效的；输入字符串中没有额外的空格，且输入的方括号总是符合格式要求的。

此外，你可以认为原始数据不包含数字，所有的数字只表示重复的次数 k ，例如不会出现像 3a 或 2[4] 的输入。

 

示例 1：

输入：s = "3[a]2[bc]"
输出："aaabcbc"
示例 2：

输入：s = "3[a2[c]]"
输出："accaccacc"
示例 3：

输入：s = "2[abc]3[cd]ef"
输出："abcabccdcdcdef"
示例 4：

输入：s = "abc3[cd]xyz"
输出："abccdcdcdxyz"
```


解法：

字符串有多层嵌套的情况，利用栈解决。使用两个栈，一个数字栈，一个字符串栈

```
public String decodeString(String s) {   
        StringBuilder result = new StringBuilder();
		Stack<Integer> multiStack = new Stack<>();
		Stack<String> subResStack = new Stack<>();
		int multi = 0;
		for(Character c : s.toCharArray()) {
			// 数字
			if (Character.isDigit(c)) {
				// 多位数字
				multi = multi * 10 + c - '0';
			} else if(c == '[') {
				multiStack.push(multi);
				subResStack.push(result.toString());
				multi = 0;
				result = new StringBuilder();
			} else if(c == ']') {
				StringBuilder temp = new StringBuilder();
				int count = multiStack.pop();
				String subString = subResStack.pop();
				for(int i = 0; i < count; i++) {
					temp.append(result);
				}
				result = new StringBuilder(subString + temp);
			} else {
				result.append(c);
			}
		}
		return result.toString();
    }
```


运行结果：

![image.png](https://b3logfile.com/file/2021/01/image-767d4bad.png)
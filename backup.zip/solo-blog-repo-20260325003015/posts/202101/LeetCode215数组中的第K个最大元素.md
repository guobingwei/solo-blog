title: LeetCode-215-数组中的第K个最大元素
date: '2021-01-04 08:48:15'
updated: '2021-01-04 08:48:15'
tags: [LeetCode, 堆]
permalink: /articles/2021/01/04/1609721294936.html
---
## 题目描述

```
在未排序的数组中找到第 k 个最大的元素。请注意，你需要找的是数组排序后的第 k 个最大的元素，而不是第 k 个不同的元素。

示例 1:

输入: [3,2,1,5,6,4] 和 k = 2
输出: 5
示例 2:

输入: [3,2,3,1,2,4,5,5,6] 和 k = 4
输出: 4

```

## 解题

排序后取第k大值

```
public int findKthLargest(int[] nums, int k) {
        Arrays.sort(nums);
        return nums[nums.length - k];
}
```


利用堆排序

```
public int findKthLargest(int[] nums, int k) {
        PriorityQueue<Integer> queue = new PriorityQueue<>();
        for(int i=0; i<nums.length; i++) {
            queue.add(nums[i]);
            if (queue.size() > k) {
                queue.poll();
            }
        }
        return queue.peek();
}
```
title: LeetCode-141-环形链表2
date: '2020-11-12 09:19:14'
updated: '2020-11-12 09:19:14'
tags: [LeetCode, 链表]
permalink: /articles/2020/11/12/1605143954625.html
---
![](https://b3logfile.com/bing/20180523.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

题目描述


给定一个链表，返回链表开始入环的第一个节点。 如果链表无环，则返回 null。

为了表示给定链表中的环，我们使用整数 pos 来表示链表尾连接到链表中的位置（索引从 0 开始）。 如果 pos 是 -1，则在该链表中没有环。注意，pos 仅仅是用于标识环的情况，并不会作为参数传递到函数中。

说明：不允许修改给定的链表。

进阶：

你是否可以使用 O(1) 空间解决此题？

![image.png](https://b3logfile.com/file/2020/11/image-359868ba.png)


解法：

1.哈希表

遍历链表中的每个节点，并将它记录下来；一旦遇到了此前遍历过的节点，就可以判定链表中存在环

2.双指针

![image.png](https://b3logfile.com/file/2020/11/image-16bfc9de.png)

代码：

```
public ListNode detectCycle(ListNode head) {
        ListNode slow = head;
        ListNode fast = head;
        while(fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            if (slow == fast) {
                fast = head;
                while(fast != slow) {
                    fast = fast.next;
                    slow = slow.next;
                }
                return fast;
            }
        }
        return null;
    }
```


运行结果：![image.png](https://b3logfile.com/file/2020/11/image-3d99b29e.png)
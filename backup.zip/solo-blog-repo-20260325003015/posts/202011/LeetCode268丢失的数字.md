title: LeetCode-268-丢失的数字
date: '2020-11-02 08:10:53'
updated: '2020-11-02 08:10:53'
tags: [LeetCode, 位运算]
permalink: /articles/2020/11/02/1604275853271.html
---
![](https://b3logfile.com/bing/20180928.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
给定一个包含 [0, n] 中 n 个数的数组 nums ，找出 [0, n] 这个范围内没有出现在数组中的那个数。

 

进阶：

你能否实现线性时间复杂度、仅使用额外常数空间的算法解决此问题?
 

示例 1：

输入：nums = [3,0,1]
输出：2
解释：n = 3，因为有 3 个数字，所以所有的数字都在范围 [0,3] 内。2 是丢失的数字，因为它没有出现在 nums 中。
示例 2：

输入：nums = [0,1]
输出：2
解释：n = 2，因为有 2 个数字，所以所有的数字都在范围 [0,2] 内。2 是丢失的数字，因为它没有出现在 nums 中。
示例 3：

输入：nums = [9,6,4,2,3,5,7,0,1]
输出：8
解释：n = 9，因为有 9 个数字，所以所有的数字都在范围 [0,9] 内。8 是丢失的数字，因为它没有出现在 nums 中。
示例 4：

输入：nums = [0]
输出：1
解释：n = 1，因为有 1 个数字，所以所有的数字都在范围 [0,1] 内。1 是丢失的数字，因为它没有出现在 nums 中。
```

## 解法

采用位运算（异或）。比如 

* 1^1^2^2^3 = 3 能找出其中只出现一次的。那如果用i ^ nums[i] ^ res 就能找到数组中不存在的数字。

代码如下：

```
public int missingNumber(int[] nums) {
        int res = nums.length;
        for(int i = 0; i < nums.length; i++) {
            res = res ^ i ^ nums[i];
        }
        return res;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-edc461b2.png)
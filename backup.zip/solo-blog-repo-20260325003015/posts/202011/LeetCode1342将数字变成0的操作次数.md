title: LeetCode-1342-将数字变成 0 的操作次数
date: '2020-11-03 23:09:08'
updated: '2020-11-03 23:09:08'
tags: [LeetCode, 位运算]
permalink: /articles/2020/11/03/1604416148026.html
---
![](https://b3logfile.com/bing/20200522.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
给你一个非负整数 num ，请你返回将它变成 0 所需要的步数。 如果当前数字是偶数，你需要把它除以 2 ；否则，减去 1 。

 

示例 1：

输入：num = 14
输出：6
解释：
步骤 1) 14 是偶数，除以 2 得到 7 。
步骤 2） 7 是奇数，减 1 得到 6 。
步骤 3） 6 是偶数，除以 2 得到 3 。
步骤 4） 3 是奇数，减 1 得到 2 。
步骤 5） 2 是偶数，除以 2 得到 1 。
步骤 6） 1 是奇数，减 1 得到 0 。
示例 2：

输入：num = 8
输出：4
解释：
步骤 1） 8 是偶数，除以 2 得到 4 。
步骤 2） 4 是偶数，除以 2 得到 2 。
步骤 3） 2 是偶数，除以 2 得到 1 。
步骤 4） 1 是奇数，减 1 得到 0 。
示例 3：

输入：num = 123
输出：12
```


# 解法

如果是偶数，向左移1位（相当于除以2），如果是奇数，跟1做异或，可以去掉低位的1，变成偶数。记录次数，直到num为0.

```
public int numberOfSteps (int num) {
        int count = 0;
        while(num > 0) {
            if (num % 2 == 0) {
                num = num >> 1;
                count++;
            }
            if (num % 2 == 1) {
                num = num ^ 1;
                count++;
            }
        }
        return count;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-786b2695.png)
title: LeetCode-剑指offer26-树的子结构
date: '2020-10-25 20:08:02'
updated: '2020-10-25 20:08:02'
tags: [LeedCode]
permalink: /articles/2020/10/25/1603627682844.html
---
## 题目描述

```java
输入两棵二叉树A和B，判断B是不是A的子结构。(约定空树不是任意一个树的子结构)

B是A的子结构， 即 A中有出现和B相同的结构和节点值。

例如:
给定的树 A:

     3
    / \
   4   5
  / \
 1   2
给定的树 B：

   4 
  /
 1
返回 true，因为 B 与 A 的一个子树拥有相同的结构和节点值。

示例 1：

输入：A = [1,2,3], B = [3,1]
输出：false
示例 2：

输入：A = [3,4,5,1,2], B = [4,1]
输出：true
限制：

0 <= 节点个数 <= 10000
```

## 解法

利用递归的思想解决。用A的根节点、左节点、右节点依次尝试是否等B的根节点，如果是则尝试对比下一个节点

go代码如下：

```
func isSubStructure(A *TreeNode, B *TreeNode) bool {
    if A == nil || B == nil {
        return false
    }

    return dfs(A, B) || isSubStructure(A.Left, B) || isSubStructure(A.Right, B)
}

func dfs(A *TreeNode, B * TreeNode) bool {
    if B == nil {
        return true
    }
    if A == nil {
        return false
    }
    return A.Val == B.Val && dfs(A.Left, B.Left) && dfs(A.Right, B.Right)
}
```

运行结果：

![image.png](https://b3logfile.com/file/2020/10/image-05f849d5.png)
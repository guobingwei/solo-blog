title: LeetCode-671-二叉树中第二小的节点
date: '2020-10-27 10:09:46'
updated: '2020-10-27 10:09:46'
tags: [LeetCode]
permalink: /articles/2020/10/27/1603764586502.html
---
# 题目描述

```java
给定一个非空特殊的二叉树，每个节点都是正数，并且每个节点的子节点数量只能为 2 或 0。如果一个节点有两个子节点的话，那么该节点的值等于两个子节点中较小的一个。

更正式地说，root.val = min(root.left.val, root.right.val) 总成立。

给出这样的一个二叉树，你需要输出所有节点中的第二小的值。如果第二小的值不存在的话，输出 -1 。

 

示例 1：


输入：root = [2,2,5,null,null,5,7]
输出：5
解释：最小的值是 2 ，第二小的值是 5 。
示例 2：


输入：root = [2,2,2]
输出：-1
解释：最小的值是 2, 但是不存在第二小的值。
 

提示：

树中节点数目在范围 [1, 25] 内
1 <= Node.val <= 231 - 1
对于树中每个节点 root.val == min(root.left.val, root.right.val)
```

# 解法

递归的解法，go代码如下：

```
func findSecondMinimumValue(root *TreeNode) int {
	if root == nil {
		return -1
	}

	return find(root, root.Val)
}

func find(node *TreeNode, minValue int) int {
	if node == nil {
		return -1
	}

	if node.Val > minValue {
		return node.Val
	}

	var left = find(node.Left, minValue)
	var right = find(node.Right, minValue)
	if left == -1 {
		return right
	}
	if right == -1 {
		return left
	}
	return min(left, right)
}

func min(a int ,b int) int {
	if a <= b {
		return a
	} else {
		return b
	}
}
```

运行结果如下：

![image.png](https://b3logfile.com/file/2020/10/image-9f4e52c0.png)
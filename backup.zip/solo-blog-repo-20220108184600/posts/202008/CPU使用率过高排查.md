title: CPU使用率过高排查
date: '2020-08-13 07:03:40'
updated: '2020-08-13 07:03:40'
tags: [待分类]
permalink: /articles/2020/08/13/1597273420800.html
---
### 1.使用top命令查询Java进程

代码块

SQL

```
top
```

![](https://km.sankuai.com/api/file/cdn/237340279/237276657?contentType=1&isNewContent=false&isNewContent=false)

定位到java进程为**369**

### 2.通过top命令定位进程包含的线程信息

代码块

SQL

```
top -H -p 369 -d 1 -n3
```

![](https://km.sankuai.com/api/file/cdn/237340279/237276848?contentType=1&isNewContent=false&isNewContent=false)

查询到线程占用率最高的线程PID 为**672**

### 3.通过jstack命令查询线程堆栈

**jstack 下的NID为16进制，672对应的16进制为223**

代码块

SQL

```
 jstack -l 369|grep -A 20 "223"
```

结果内容为：

![](https://km.sankuai.com/api/file/cdn/237340279/237421767?contentType=1&isNewContent=false&isNewContent=false)

至此，可以根据代码去定位问题

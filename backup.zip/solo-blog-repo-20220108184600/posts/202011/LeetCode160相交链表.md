title: LeetCode-160-相交链表
date: '2020-11-06 23:41:17'
updated: '2020-11-08 00:24:03'
tags: [LeetCode, 链表]
permalink: /articles/2020/11/06/1604677277851.html
---
![](https://b3logfile.com/bing/20180105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

编写一个程序，找到两个单链表相交的起始节点。

![image.png](https://b3logfile.com/file/2020/11/image-9f6ba58e.png)

# 解法

定义两个指针, 第一轮让两个到达末尾的节点指向另一个链表的头部, 最后如果相遇则为交点(在第一轮移动中恰好抹除了长度差)
两个指针等于移动了相同的距离, 有交点就返回, 无交点就是各走了两条指针的长度

```
 public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        if (headA == null || headB == null) {
            return null;
        }
        ListNode nodeA = headA;
        ListNode nodeB = headB;

        while(nodeA != nodeB) {
            nodeA = nodeA == null ? headB : nodeA.next;
            nodeB = nodeB == null ? headA : nodeB.next;
        }
        return nodeA;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-076bce45.png)

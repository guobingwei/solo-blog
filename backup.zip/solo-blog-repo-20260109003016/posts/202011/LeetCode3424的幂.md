title: LeetCode-342-4的幂
date: '2020-11-04 08:06:04'
updated: '2020-11-04 08:06:04'
tags: [LeetCode, 位运算]
permalink: /articles/2020/11/04/1604448364446.html
---
![](https://b3logfile.com/bing/20200618.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目

```
给定一个整数 (32 位有符号整数)，请编写一个函数来判断它是否是 4 的幂次方。

示例 1:

输入: 16
输出: true
示例 2:

输入: 5
输出: false
```

# 解法

位运算、借助 & 和 % 。4的幂次方最高位是1，其他位都是0，且 % 3 值为1

```
public boolean isPowerOfFour(int num) {
        return num > 0 && (num & (num - 1)) == 0 && (num % 3 == 1);
}
```
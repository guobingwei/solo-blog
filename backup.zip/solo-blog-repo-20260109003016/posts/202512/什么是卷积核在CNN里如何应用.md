title: 什么是卷积核，在CNN里如何应用？
date: '2025-12-26 16:25:31'
updated: '2025-12-26 22:47:00'
tags: [机器学习]
permalink: /articles/2025/12/26/1766737531344.html
---
![](https://b3logfile.com/bing/20241225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 一句话定义

> **卷积核（Kernel / Filter）是一组可学习的小矩阵，用来在局部区域内提取特定模式的特征。**

这句话合格，但不加分。下面才是加分部分。

---

## 一、直觉理解（一定要会讲）

### 你可以这样想👇

* 输入是一张大图（或特征图）
* 卷积核是一只 **“小窗口 + 模板”**
* 在图上滑动
* 每滑一次就问一句：

> “这一小块，像不像我关心的模式？”

---

### 举个具体例子

一个 **3×3 卷积核**可能学到的是：

* 横向边缘
* 竖向边缘
* 角点
* 纹理

👉 不同卷积核 = 不同“特征探测器”

📌 面试金句：

> 每个卷积核本质上是一个“模式检测器”。

---

## 二、数学定义（别躲）

假设：

* 输入特征图：`X`
* 卷积核：`W`
* 输出特征图：`Y`

对某个位置 `(i, j)`：

<pre class="overflow-visible! px-0!" data-start="477" data-end="519"><div class="contain-inline-size rounded-2xl corner-superellipse/1.1 relative bg-token-sidebar-surface-primary"><div class="sticky top-[calc(--spacing(9)+var(--header-height))] @w-xl/main:top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>Y(i,j) = Σ Σ X(i+u, j+v) · W(u, v)
</span></span></code></div></div></pre>

👉 本质就是 **加权求和**

⚠️ 严格来说 CNN 里用的是  **互相关（cross-correlation）** ，但工程上仍叫卷积。

📌 加分点：

> 深度学习里的“卷积”其实不翻转 kernel。

---

## 三、卷积核在 CNN 里的三个关键作用

---

### 1️⃣ 局部连接（Local Connectivity）

* 卷积核只看 **局部区域**
* 不看全图

👉 大幅减少参数量

对比：

* 全连接：O(n²)
* 卷积：O(k²)

---

### 2️⃣ 权重共享（Weight Sharing）

* 同一个卷积核
* 在整张图上反复使用

👉 同一个模式，无论出现在左上还是右下，都能被识别

📌 金句：

> 卷积核让 CNN 具有平移不变性。

---

### 3️⃣ 特征抽象（层级化）

* 浅层：边缘、角点
* 中层：纹理、形状
* 深层：物体部件、语义

👉 **卷积核是层级特征的构建单元**

---

## 四、工程角度怎么理解卷积核？

### 1️⃣ 一个卷积层 ≠ 一个卷积核

* 一个卷积层通常有 **N 个卷积核**
* 每个核生成一张特征图（channel）

<pre class="overflow-visible! px-0!" data-start="1049" data-end="1099"><div class="contain-inline-size rounded-2xl corner-superellipse/1.1 relative bg-token-sidebar-surface-primary"><div class="sticky top-[calc(--spacing(9)+var(--header-height))] @w-xl/main:top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>输入：C_in 通道
卷积核：C_in × k × k
输出：1 个 channel
</span></span></code></div></div></pre>

---

### 2️⃣ 多通道卷积核

对 RGB 输入：

<pre class="overflow-visible! px-0!" data-start="1133" data-end="1165"><div class="contain-inline-size rounded-2xl corner-superellipse/1.1 relative bg-token-sidebar-surface-primary"><div class="sticky top-[calc(--spacing(9)+var(--header-height))] @w-xl/main:top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>Kernel</span><span></span><span>shape</span><span></span><span>=</span><span> (</span><span>3</span><span>, k, k)
</span></span></code></div></div></pre>

* 分别对 R/G/B 做卷积
* 再相加

📌 面试加分点：

> 多通道卷积是在通道维度上做加权融合。

---

## 五、卷积核大小意味着什么？


| 大小 | 意义                     |
| ------ | -------------------------- |
| 1×1 | 通道变换 / 降维          |
| 3×3 | 最常用，平衡感受野与计算 |
| 5×5 | 感受野大，计算重         |
| 7×7 | 常用于第一层             |

📌 面试金句：

> 多个 3×3 卷积可以替代一个大卷积核，同时更省参数。

---

## 六、卷积核是“人设定”的还是“学出来的”？

> **完全是学出来的。**

* 初始：随机
* 训练：反向传播更新权重
* 最终：自动学到有意义的模式

👉 人不需要指定“这是边缘核”

## 八、终极总结

> 卷积核是 CNN 中可学习的局部模板，
>
> 通过局部连接和权重共享，在整张输入上提取一致的模式，
>
> 是 CNN 能高效建模空间结构的核心原因。

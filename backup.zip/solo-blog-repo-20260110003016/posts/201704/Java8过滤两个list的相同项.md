title: Java 8 过滤两个list的相同项
date: '2017-04-06 18:10:39'
updated: '2017-04-06 18:10:39'
tags: [Java]
permalink: /articles/2017/04/06/1491473439725.html
---
假如有两个list，list1=[1, 2, 4, 5]，list2=[2, 4, 6, 7]，求相同项

## 方法一
```
 List<Integer> availablePoiList = requestPoiList.stream().filter(requestPoi -> memberPoiIdList.stream().anyMatch(availablePoi -> availablePoi.equals(requestPoi))).collect(Collectors.toList());
```

## 方法二

```
List<Integer> availablePoiList = requestPoiList.stream().filter(memberPoiIdList::contains).collect(Collectors.toList());
```

第二种方法简洁了很多，刚开始不会用lambda，写出来比较长，后面找到了contains方法。
title: 堆外内存排查Perf
date: '2020-08-13 07:05:38'
updated: '2020-08-13 07:05:38'
tags: [待分类]
permalink: /articles/2020/08/13/1597273538755.html
---
使用 perf record -g -p 55 开启监控栈函数调用。运行一段时间后Ctrl+C结束，会生成一个文件perf.data。

代码块

Java

```
perf record -g -p pid
```

执行perf report -i perf.data查看报告。

代码块

Java

```
perf report -i perf.data
```

参考文档：

[https://www.ibm.com/developerworks/cn/linux/l-cn-perf1/index.html](https://www.ibm.com/developerworks/cn/linux/l-cn-perf1/index.html)

[https://blog.csdn.net/lycyingO/article/details/80854669](https://blog.csdn.net/lycyingO/article/details/80854669)
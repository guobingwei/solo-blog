title: Java正则表达式之Pattern类和Matcher类
date: '2016-09-29 10:32:21'
updated: '2016-09-29 10:32:21'
tags: [正则表达式]
permalink: /articles/2016/09/29/1475116341562.html
---
---


###Pattern类
Pattern类用于创建一个正则表达，或者说是一种匹配模式,它的构造方法是私有的,不可以直接创建,但可以通过Pattern.complie(String regex)简单工厂方法创建一个正则表达式。
Java代码示例: 
```
Pattern p=Pattern.compile("\\w+"); 
p.pattern();//返回 \w+ 
```

Pattern.split(CharSequence input) ,用于分隔字符串
```
Pattern p=Pattern.compile("\\d+"); 
String[] str=p.split("我的QQ是:456456我的电话是:0532214我的邮箱是:aaa@aaa.com"); 

结果:str[0]="我的QQ是:" str[1]="我的电话是:" str[2]="我的邮箱是:aaa@aaa.com" 
```

Pattern.matcher(String regex,CharSequence input),快速匹配字符串，该方法适合用于只匹配一次,且匹配全部字符串. 
Java代码示例: 
```
Pattern.matches("\\d+","2223");//返回true 
Pattern.matches("\\d+","2223aa");//返回false,需要匹配到所有字符串才能返回true,这里aa不能匹配到 
Pattern.matches("\\d+","22bb23");//返回false,需要匹配到所有字符串才能返回true,这里bb不能匹配到 
```

Pattern.matcher(CharSequence input) ,返回一个Matcher对象. 
通常用法：
```
Pattern.compile(regex).matcher(input).matches();
```

lookingAt()对前面的字符串进行匹配,只有匹配到的字符串在最前面才返回true 
find()对字符串进行匹配,匹配到的字符串可以在任何位置.
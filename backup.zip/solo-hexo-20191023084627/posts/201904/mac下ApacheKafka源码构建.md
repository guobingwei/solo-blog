title: mac 下Apache Kafka 源码构建
date: '2019-04-16 15:24:43'
updated: '2019-04-24 07:16:12'
tags: [mac]
permalink: /articles/2019/04/16/1555399483061.html
---
# 1. Java环境安装

Java 环境需要jdk 8及以上。大家都会安装，省略

# 2. gradle 环境安装

gradle版本必须是5.0以上，我本地已经安装过gradle，只能版本比较低，需要升级，mac 下命令如下：

`brew upgrade gradle`

如果首次安装的话执行

`brew install gradle`

卸载重装使用命令：
`brew reinstall gradle`

# 3. scala环境安装

```
brew update
brew install scala
```

# 4. kafka源码构建
下载源代码到本地，然后构建
```
cd kafka_source_dir
gradle
```
title: LeetCode-1365-每日一题-独一无二的出现次数
date: '2020-10-28 08:25:21'
updated: '2020-10-28 08:25:21'
tags: [LeetCode, 每日一题]
permalink: /articles/2020/10/28/1603844721220.html
---
# 题目描述

```go
给你一个整数数组 arr，请你帮忙统计数组中每个数的出现次数。

如果每个数的出现次数都是独一无二的，就返回 true；否则返回 false。

 

示例 1：

输入：arr = [1,2,2,1,1,3]
输出：true
解释：在该数组中，1 出现了 3 次，2 出现了 2 次，3 只出现了 1 次。没有两个数的出现次数相同。
示例 2：

输入：arr = [1,2]
输出：false
示例 3：

输入：arr = [-3,0,1,-3,1,1,1,-3,10,0]
输出：true
```

# 解法

使用哈希表解决，第一遍存储每个数字出现的次数，第二遍存储用set存储出现的次数，如果set插入重复，即不是独一无二的出现次数

```
public boolean uniqueOccurrences(int[] arr) {

		Map<Integer, Integer> arrCountMap = new HashMap<>();
		for(int i = 0; i < arr.length; i++) {
			arrCountMap.put(arr[i], arrCountMap.getOrDefault(arr[i], 0) + 1);
		}

		Set<Integer> timeSet = new HashSet<>();
		for(Integer attr : arrCountMap.values()) {
			if(!timeSet.add(attr)) {
				return false;
			}
		}

		return arrCountMap.size() == timeSet.size();
	}
```

运行结果如下：

![image.png](https://b3logfile.com/file/2020/10/image-a49d1825.png)

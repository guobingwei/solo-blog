title: CentOS 7下 Docker容器安装
date: '2019-03-28 07:52:42'
updated: '2019-03-28 08:10:22'
tags: [Docker]
permalink: /articles/2019/03/28/1553730762270.html
---
![](https://img.hacpai.com/bing/20171105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 1. 环境检查


## 1. 1 前提条件

目前，CentOS 仅发行版本中的内核支持 Docker。

Docker 运行在 CentOS 7 上，要求系统为64位、系统内核版本为 3.10 以上。

Docker 运行在 CentOS-6.5 或更高的版本的 CentOS 上，要求系统为64位、系统内核版本为 2.6.32-431 或者更高版本。

## 1.2. 系统版本检查
通过`uname -r`查看当前系统内核版本，我的机器内核版本如下：
```
[root@iZ94ixkobxaZ ~]# uname -r
3.10.0-514.21.1.el7.x86_64
```

## 2. yum安装（CentOS 7）

##  2.1. 旧版本移除（可选）
```
sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine
```

## 2.2. 安装系统工具
```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```
## 2.3. 添加软件信息
```sudo yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo```

## 2.4. 更新yum缓存
```
sudo yum makecache fast
```
## 2.6 安装Docker CE
```
sudo yum -y install docker-ce
```

## 2.7. 启动 Docker 后台服务
```
sudo systemctl start docker
```

至此，docker容器安装完成。可以通过`docker ps `查看docker进程。显示如下：
```
[root@iZ94ixkobxaZ ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
```
会展示容器ID、镜像、状态等信息。

## 2.8. 删除容器（如果需要）
```
sudo yum remove docker-ce
sudo rm -rf /var/lib/docker
```

title: LeetCode-Palindrome Number
date: '2020-04-04 11:24:57'
updated: '2020-04-04 11:24:57'
tags: [LeedCode]
permalink: /articles/2020/04/04/1585970697040.html
---
# 1. 题目描述

```
Determine whether an integer is a palindrome. An integer is a palindrome when it reads the same backward as forward.

Example 1:

Input: 121
Output: true
Example 2:

Input: -121
Output: false
Explanation: From left to right, it reads -121. From right to left, it becomes 121-. Therefore it is not a palindrome.
Example 3:

Input: 10
Output: false
Explanation: Reads 01 from right to left. Therefore it is not a palindrome.
```

# 2. 解题思路

### 2.1 先反转数字，再判断是否相等

* 负数是不可能回文的，直接返回false
* 把数字反转，跟原来的值比较是否相等

```
class Solution {
    public boolean isPalindrome(int x) {
        if (x < 0) {
            return false;
        }
        int reverse = reverse(x);
        return reverse == x;
    }

    public int reverse(int x) {
        int n = 0;
        while(x != 0) {
            n = n * 10 + x % 10;
            x = x/10;
        }
        return n;
    }
}
```

**运行结果为：**
![image.png](https://img.hacpai.com/file/2020/04/image-dbbb6dfc.png)

这里不存在数组越界的问题，因为int的最大值除以10是不会超过int最大值的。
从运行结果来看，运行速度还是可以接受的。但是内存消耗很大，有进一步的优化空间

### 2.2 优化，只判断一半的数字

1. 从末尾数字开始判断起，从右往左移（x % 10）,前半部分数字 x /10，直到两个数字相同或者end > begin 结束

```
public boolean isPalindrome(int x) {
		if (x < 0 || (x / 10 != 0 && x % 10 == 0)) {
			return false;
		}

		int end = 0;

		while (x > end) {
			end = end * 10 + x % 10;
			x = x / 10;
		}

		return x == end || x == end / 10;
	}
```

执行结果：
![image.png](https://img.hacpai.com/file/2020/04/image-fccf2f47.png)

疑惑是内存和耗时咋没变化呢，奇怪了，明明是有优化的
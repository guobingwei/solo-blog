title: Transformer 相比CNN和RNN有啥优势？
date: '2025-12-26 16:10:19'
updated: '2025-12-26 16:10:19'
tags: [大模型]
permalink: /articles/2025/12/26/1766736619228.html
---
## 一句话结论

> **Transformer 的核心优势不是“Attention”，而是：
>
> 用全局依赖 + 高并行，解决了 CNN 看不远、RNN 跑不快的问题。**

---

## 一、对比总览（先拉开差距）


| 维度       | CNN      | RNN / LSTM | Transformer        |
| ------------ | ---------- | ------------ | -------------------- |
| 依赖建模   | 局部     | 顺序依赖   | **全局依赖**       |
| 并行能力   | 高       | **低**     | **极高**           |
| 长距离依赖 | 差       | 有但会衰减 | **强**             |
| 训练速度   | 快       | 慢         | **快（GPU 友好）** |
| 表达能力   | 位置敏感 | 时序强     | **语义关系强**     |

---

## 二、Transformer 相比 CNN 的优势

### 1️⃣ CNN 天生是“近视眼”

* CNN 靠 **局部卷积核**
* 想看远 → 必须堆很多层
* 信息传递路径长，**语义被稀释**

👉 Transformer：

* **一次 Attention 就能看全局**
* 任意两个 token 距离都是 O(1)

📌 面试金句：

> CNN 的感受野是“堆出来的”，Transformer 的感受野是“天生的”。

---

### 2️⃣ CNN 更擅长空间，不擅长语义关系

* CNN 强在：边缘、纹理、局部模式
* 弱在：**“谁和谁有关系”**

👉 Transformer：

* Attention 本质是 **关系建模**
* 非连续、跨位置关系直接建模

---

## 三、Transformer 相比 RNN 的优势（重点）

### 1️⃣ 并行性：这是决定性优势

* RNN：

  <pre class="overflow-visible! px-0!" data-start="836" data-end="863"><div class="contain-inline-size rounded-2xl corner-superellipse/1.1 relative bg-token-sidebar-surface-primary"><div class="sticky top-[calc(--spacing(9)+var(--header-height))] @w-xl/main:top-9"><div class="absolute end-0 bottom-0 flex h-9 items-center pe-2"><div class="bg-token-bg-elevated-secondary text-token-text-secondary flex items-center gap-4 rounded-sm px-2 font-sans text-xs"></div></div></div><div class="overflow-y-auto p-4" dir="ltr"><code class="whitespace-pre!"><span><span>h</span><span>(t) 必须等 </span><span>h</span><span>(t-</span><span>1</span><span>)
  </span></span></code></div></div></pre>

  👉 **无法并行**
* Transformer：

  * 所有 token **一次性 Attention**
  * GPU / TPU 利用率极高

📌 面试金句：

> RNN 的瓶颈在时间轴，Transformer 直接把时间轴“拍平”。

---

### 2️⃣ 长距离依赖不衰减

* RNN / LSTM：
  * 理论可记忆
  * 实际：梯度衰减 + 门控失效
* Transformer：
  * 任意 token 直接建立连接
  * 不存在“传了 100 步记不住”的问题

---

### 3️⃣ 表达能力更灵活

* RNN 是 **固定状态压缩**
* Transformer 是 **动态加权组合**

👉 每个 token 都能“选择”关注谁

---

## 四、为什么 Transformer 成了“大一统架构”

这不是偶然，是工程 + 数学的必然结果：

### 1️⃣ 架构统一

* NLP：BERT / GPT
* CV：ViT
* 语音：Whisper
* 多模态：CLIP / GPT-4o

👉 **同一套 Attention + FFN**

---

### 2️⃣ Scaling Law 成立

* 模型越大 → 效果越好
* 数据越多 → 性能越稳

📌 CNN / RNN 在大规模下都遇到瓶颈

📌 Transformer 越堆越强

---

## 五、那 Transformer 没缺点吗？

❌ 计算复杂度高

* Attention：O(n²)
* 长序列成本爆炸

### ❌ 位置信息是“外挂”

* CNN / RNN：天然有位置信息
* Transformer：靠 Position Encoding

👉 所以后来才有：

* Longformer
* Performer
* FlashAttention

---

## 六、终极对比总结

> CNN 擅长局部模式，
>
> RNN 擅长顺序建模但难并行，
>
> Transformer 用 Attention 把“全局依赖 + 并行计算”一次性解决，
>
> 是第一个真正适合大规模训练的通用序列建模架构。

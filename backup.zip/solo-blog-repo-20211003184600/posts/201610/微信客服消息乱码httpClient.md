title: 微信客服消息乱码-httpClient
date: '2016-10-18 21:13:55'
updated: '2016-10-18 21:13:55'
tags: [微信开发]
permalink: /articles/2016/10/18/1476796435559.html
---
## 问题描述

今日测试微信客服消息接口、发过去之后微信发给用户的是乱码，Google了一下，解决办法很多，但是都不能解决我的问题。我用的是Apache的httpClient。

之前一直是乱码的代码：
```
entity = new StringEntity(JSON.toJSONString(postForm));
entity.setContentEncoding(StandardCharsets.UTF_8.toString());
entity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
```

我是用了utf-8编码，ContentEncoding是utf-8，但是还是乱码。。。。经过一番尝试，map转json的时候编码可能发生了变化。
我把代码这样写了一下，`StringEntity()`的时候也加了一下编码。问题解决了。

```
entity = new StringEntity(JSON.toJSONString(postForm), "UTF-8");
entity.setContentEncoding(StandardCharsets.UTF_8.toString());
entity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
```
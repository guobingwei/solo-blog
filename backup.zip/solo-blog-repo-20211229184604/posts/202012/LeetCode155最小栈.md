title: LeetCode-155-最小栈
date: '2020-12-01 09:08:36'
updated: '2020-12-01 09:08:36'
tags: [LeetCode, 栈]
permalink: /articles/2020/12/01/1606784916260.html
---
题目

```
设计一个支持 push ，pop ，top 操作，并能在常数时间内检索到最小元素的栈。

push(x) —— 将元素 x 推入栈中。
pop() —— 删除栈顶的元素。
top() —— 获取栈顶元素。
getMin() —— 检索栈中的最小元素。
```


解法：


我们只需要设计一个数据结构，使得每个元素 a 与其相应的最小值 m 时刻保持一一对应。因此我们可以使用一个辅助栈，与元素栈同步插入与删除，用于存储与每个元素对应的最小值。

当一个元素要入栈时，我们取当前辅助栈的栈顶存储的最小值，与当前元素比较得出最小值，将这个最小值插入辅助栈中；

当一个元素要出栈时，我们把辅助栈的栈顶元素也一并弹出；

在任意一个时刻，栈内元素的最小值就存储在辅助栈的栈顶元素中。


```
class MinStack {
    Stack<Integer> stack;
    Stack<Integer> minStack;
    /** initialize your data structure here. */
    public MinStack() {
        stack = new Stack<>();
        minStack = new Stack<>();
        minStack.push(Integer.MAX_VALUE);
    }
  
    public void push(int x) {
        stack.push(x);
        minStack.push(Math.min(minStack.peek(), x));
    }
  
    public void pop() {
        stack.pop();
        minStack.pop();
    }
  
    public int top() {
        return stack.peek();
    }
  
    public int getMin() {
        return minStack.peek();
    }
}
```


运行结果：

![image.png](https://b3logfile.com/file/2020/12/image-94f40190.png)

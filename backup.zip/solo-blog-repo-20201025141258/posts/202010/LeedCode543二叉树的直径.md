title: LeedCode-543-二叉树的直径
date: '2020-10-25 02:36:21'
updated: '2020-10-25 02:36:21'
tags: [LeedCode]
permalink: /articles/2020/10/25/1603564581165.html
---
## 题目

```go
给定一棵二叉树，你需要计算它的直径长度。一棵二叉树的直径长度是任意两个结点路径长度中的最大值。这条路径可能穿过也可能不穿过根结点。

 

示例 :
给定二叉树

          1
         / \
        2   3
       / \   
      4   5  
返回 3, 它的长度是路径 [4,2,1,3] 或者 [5,2,1,3]。
```

## 解法

可以将二叉树的直径转换为：二叉树的 每个节点的左右子树的高度和 的最大值。

go代码实现如下：

```go
var ans int = 0
func diameterOfBinaryTree(root *TreeNode) int {

	ans = 0
	depth(root)
	return ans
}

func depth(node *TreeNode) int {
	if node == nil {
		return 0
	}

	var leftDepth, rightDepth  = depth(node.Left), depth(node.Right)
	ans = max(leftDepth + rightDepth, ans)

	return 1 + max(leftDepth, rightDepth)
}

func max(a int, b int) int {
	if a >= b {
		return a
	} else {
		return b
	}
}
```

看着代码挺多，其实核心就depth() 这个函数，逻辑比较清晰。

![image.png](https://b3logfile.com/file/2020/10/image-2cf52606.png)

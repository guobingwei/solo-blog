title: Git 初始化仓库
date: '2020-04-01 18:18:16'
updated: '2020-04-03 14:56:18'
tags: [待分类]
permalink: /articles/2020/04/01/1585736296378.html
---
```
If you already have code ready to be pushed to this repository then run this in your terminal.
cd existing-project

git init

git add --all

git commit -m "Initial Commit"

git remote add origin ssh://git@git.xxx.com/cyhy/xxxx.git

git push origin master

If your code is already tracked by Git then set this repository as your `origin` to push to.
cd existing-project

git remote set-url origin ssh://git@git.xxx.com/cyhy/xxxx.git
git push origin master

All done with the commands?
```

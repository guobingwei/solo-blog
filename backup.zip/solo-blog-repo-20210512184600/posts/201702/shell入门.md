title: shell 入门
date: '2017-02-22 15:47:53'
updated: '2017-02-22 16:09:33'
tags: [shell]
permalink: /articles/2017/02/22/1487749673034.html
---

标签（空格分隔）： shell

---

## 1. 简介
Shell 是一个用C语言编写的程序，它是用户使用Linux的桥梁。Shell既是一种命令语言，又是一种程序设计语言。
Linux的Shell种类众多，常见的有：
>* Bourne Shell（/usr/bin/sh或/bin/sh）
>* Bourne Again Shell（/bin/bash）
>* C Shell（/usr/bin/csh）
>* K Shell（/usr/bin/ksh）
>* Shell for Root（/sbin/sh）

在一般情况下，人们并不区分 Bourne Shell 和 Bourne Again Shell，所以，像 #!/bin/sh，它同样也可以改为#!/bin/bash。

## 2.举例
```
#!/bin/bash
echo "Hello World !"
```
保存为test.sh, 执行chmod 777 test.sh赋予执行权限，再执行脚本`./test.sh`,

**注意:**
一定要写成./test.sh，而不是test.sh，运行其它二进制的程序也一样，直接写test.sh，linux系统会去PATH里寻找有没有叫test.sh的，而只有/bin, /sbin, /usr/bin，/usr/sbin等在PATH里，你的当前目录通常不在PATH里，所以写成test.sh是会找不到命令的，要用./test.sh告诉系统说，就在当前目录找。

## 3. 变量

```
your_name="weiguobing"
```
变量名不加美元符号。变量名和等号之间不能有空格。
除了显式地直接赋值，还可以用语句给变量赋值，如：
```
for file in `ls /etc`
```
以上语句将 /etc 下目录的文件名循环出来。
title: TOP命令解释
date: '2020-08-13 07:06:26'
updated: '2020-08-13 07:06:26'
tags: [待分类]
permalink: /articles/2020/08/13/1597273585957.html
---
输入top命令之后：

![](https://km.sankuai.com/api/file/cdn/232286086/232233672?contentType=1&isNewContent=false&isNewContent=false)

总共有这些指标：

![](https://km.sankuai.com/api/file/cdn/232286086/232321710?contentType=1&isNewContent=false&isNewContent=false)

每个字段具体什么意思呢？

| 名称 | 英文解释 | 说明 | 备注  |
|  ---  |  ---  | ---- |  ---  |
| PID | Process Id | 进程ID | x  |
| USER | User Name | 优先级 |   |
| PR | Priority | ？ |   |
| NI | Nice value | 虚拟镜像 |   |
| VIRT | Virtual Image |   |   |
| RES | Resident size |   |   |
| SHR | Shared Mem size |   |   |
| S | Process Status |   |   |
| %CPU |   |   |   |
| %MEM |   |   |   |
| TIME+ |   |   |   |
| COMMAND |   |   |   |
title: LeedCode-Reverse Integer
date: '2020-04-04 11:32:26'
updated: '2020-04-04 11:32:48'
tags: [leedcode]
permalink: /articles/2020/04/04/1585971146018.html
---
# 1.题目描述
```
Given a 32-bit signed integer, reverse digits of an integer.

Example 1:

Input: 123
Output: 321
Example 2:

Input: -123
Output: -321
Example 3:

Input: 120
Output: 21
```
# 2. 解法

很基础的做法，通过除法，取余找到每位的数字进行反转

```
public int reverse(int x) {
        long n = 0;
        while(x != 0) {
            n = n * 10 + x % 10;
            x = x / 10;
        }
        return (int)n==n? (int)n:0;
    }
```
运行结果：
![image.png](https://img.hacpai.com/file/2020/04/image-047874d5.png)


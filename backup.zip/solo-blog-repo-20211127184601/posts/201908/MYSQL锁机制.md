title: MYSQL锁机制
date: '2019-08-14 08:32:21'
updated: '2020-03-28 20:16:45'
tags: [待分类]
permalink: /articles/2019/08/14/1565742741093.html
---
参考文档：
https://yq.aliyun.com/articles/646976

http://hedengcheng.com/?p=771

[一篇搞定 MySQL 锁机制面试](http://m.nowcoder.com/discuss/151430?type=0&pos=6)

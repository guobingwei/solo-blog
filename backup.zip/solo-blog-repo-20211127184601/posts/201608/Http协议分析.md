title: Http协议分析
date: '2016-08-10 23:04:51'
updated: '2016-08-12 08:58:16'
tags: [协议]
permalink: /articles/2016/08/10/1470841491593.html
---


---

http请求都分为请求（响应）行，请求（响应）头（header），body三部分。

# 1. http首部
## 1.1 Host：
客户端通过host首部为服务器提供客户端想要访问的那台服务器的ip地址。告诉服务器我要访问哪台主机。
## 1.2 Expires 
响应失效的日期和时间
## 1.3 Etag 
为报文中的实体提供了实体标记。
## 1.4 Cache-Control
控制缓存的行为（no cache）
## 1.6 Upgrade	
升级为其他协议(websocket的时候这个字段为`websocket`)
## 1.7 User-Agent	
HTTP 客户端设备信息。
## 1.8 Referer
**意义**
告诉服务器我是从哪个页面链接过来的，服务器籍此可以获得一些信息用于处理。比如从我主页上链接到一个朋友那里，他的服务器就能够从HTTP Referer中统计出每天有多少用户点击我主页上的链接访问他的网站。

**作用**
> *  Referer可以记录访问的来源，统计访问量，可以用来防盗链。
> *  客户端用js不能篡改Referer，用一些插件什么的可以达到伪造的目的。
> *  可以使用Fiddler修改Referer。
> * 利用Referer防止图片盗链

## 1.9 X-Requested-With
在服务器端判断request来自Ajax请求(异步)还是传统请求(同步)：

websocket协议的请求头
```
Accept-Encoding:gzip, deflate, sdch
Accept-Language:zh-CN,zh;q=0.8
Cache-Control:no-cache
Connection:Upgrade
Host:ws.innohub.io
Origin:http://bp.innohub.io
Pragma:no-cache
Sec-WebSocket-Extensions:permessage-deflate; client_max_window_bits
Sec-WebSocket-Key:IPUHmYqNh5thaasaVoB3lA==
Sec-WebSocket-Version:13
Upgrade:websocket
User-Agent:Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36

```
---

未完待续。。。。


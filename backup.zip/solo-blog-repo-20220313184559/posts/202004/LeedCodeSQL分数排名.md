title: LeedCode-SQL-分数排名
date: '2020-04-12 02:40:37'
updated: '2020-04-12 02:53:00'
tags: [LeedCode, SQL]
permalink: /articles/2020/04/12/1586630437266.html
---
# 题目描述

编写一个 SQL 查询来实现分数排名。

```
如果两个分数相同，则两个分数排名（Rank）相同。请注意，平分后的下一个名次应该是下一个连续的整数值。换句话说，名次之间不应该有“间隔”。

+----+-------+
| Id | Score |
+----+-------+
| 1  | 3.50  |
| 2  | 3.65  |
| 3  | 4.00  |
| 4  | 3.85  |
| 5  | 4.00  |
| 6  | 3.65  |
+----+-------+
例如，根据上述给定的 Scores 表，你的查询应该返回（按分数从高到低排列）：

+-------+------+
| Score | Rank |
+-------+------+
| 4.00  | 1    |
| 4.00  | 1    |
| 3.85  | 2    |
| 3.65  | 3    |
| 3.65  | 3    |
| 3.50  | 4    |
+-------+------+
```

# 解法

这个问题分为两部分来看

* 所有的分数按由大到小的顺序排序
* 针对排好的分数，给出排名

那第一部分，写出来很轻松

```
`select Score from Scores order by Score desc`
```

第二部分，稍微难一点。可以这么理解，所有的元素去重后找出比当前分数大的个数，那就是当前分数的排名，sql 如下

```
select count(distinct Score) from Score where Score >= x
```

综合起来，SQL写为如下：

```
select Score,
 (select count(distinct Score)  from Scores where Score >= s.Score) as Rank

 from Scores s order by Score desc;
```

**执行结果**
![image.png](https://img.hacpai.com/file/2020/04/image-7ca0707b.png)


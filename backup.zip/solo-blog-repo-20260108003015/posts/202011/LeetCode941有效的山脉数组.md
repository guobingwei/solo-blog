title: LeetCode-941-有效的山脉数组
date: '2020-11-03 22:58:18'
updated: '2020-11-03 22:58:18'
tags: [LeetCode, 每日一题]
permalink: /articles/2020/11/03/1604415498477.html
---
![](https://b3logfile.com/bing/20180710.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
给定一个整数数组 A，如果它是有效的山脉数组就返回 true，否则返回 false。

让我们回顾一下，如果 A 满足下述条件，那么它是一个山脉数组：

A.length >= 3
在 0 < i < A.length - 1 条件下，存在 i 使得：
A[0] < A[1] < ... A[i-1] < A[i]
A[i] > A[i+1] > ... > A[A.length - 1]

示例 1：

输入：[2,1]
输出：false
示例 2：

输入：[3,5,5]
输出：false
示例 3：

输入：[0,3,2,1]
输出：true
 

提示：

0 <= A.length <= 10000
0 <= A[i] <= 10000 
```


# 解法

利用二分的思路。从两头往中间找。判断中间节点是否相同。

```

if (A.length < 3) {
            return false;
        }

        if(A[0] > A[1]) {
            return false;
        }
        int i = 0;
        while(i < A.length - 1 && A[i] <= A[i+1]) {
            i++;  
        }

        int j = A.length - 1;
        while(j > 0 && A[j] < A[j - 1]) {
            j--;
        }

        return i > 0 && j < A.length -1 && i == j;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-3648607a.png)
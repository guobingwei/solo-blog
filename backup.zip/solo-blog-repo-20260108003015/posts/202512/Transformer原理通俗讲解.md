title: Transformer 原理通俗讲解
date: '2025-12-23 14:39:38'
updated: '2025-12-23 14:39:38'
tags: [大模型]
permalink: /articles/2025/12/23/1766471978859.html
---
![](https://b3logfile.com/bing/20190409.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

* 核心思路：用“注意力”计算序列内各位置间的相关性，替代 RNN/CNN 的逐步传递，便于并行、捕捉长依赖。
* 输入层：把词/子词转成向量（Embedding），加上位置编码（Positional Encoding）告诉模型顺序。
* 典型堆叠：几十到上百层（小模型 6–12 层，大模型几十到几百层），每层结构几乎相同。
* 单层结构（Encoder/Decoder 的基本块）：
* 多头自注意力（Multi-Head Self-Attention）：并行算多组注意力，抓不同类型/范围的关联；Decoder 的自注意力带 Mask，避免看见未来。
* 残差 + LayerNorm：保持梯度稳定，加速训练。
* 前馈网络（Feed-Forward / MLP）：对每个位置单独做非线性变换，提升表示能力。
* Decoder 额外的“交叉注意力”（Cross-Attention）：在序列到序列场景里，用来关注 Encoder 输出（翻译、对话等）。
* 输出层：线性映射 + Softmax 生成下一个 token 概率，按自回归方式一步步生成。

一句话：Embedding + 位置编码 → N 层（多头自注意力 + 残差 + LayerNorm + 前馈）堆叠；若是序列到序列，再在 Decoder 加交叉注意力；用注意力权重决定“当前要看谁”，多头并行看不同关系，层数越深，语义抽象越强。

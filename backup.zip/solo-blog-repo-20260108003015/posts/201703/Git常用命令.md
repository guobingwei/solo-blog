title: Git 常用命令
date: '2017-03-24 09:56:29'
updated: '2017-03-24 09:56:29'
tags: [Git]
permalink: /articles/2017/03/24/1490320588924.html
---
---
co 是checkout的意思，配置了别名。
## 1. 把远程没有拉取过的分支拉取到本地
```
git co master // 会把远程的master拉到本地，并且建立关联
```
## 2. 创建本地分支并推送到远程
```
1.  git co -b test // 创建本地分支test
```
```
2.  git co -b test // 创建本地分支test
```
```
3. git push origin wei  // 把本地分支推到远程

```
## 3. 本地分支和远程分支建立关联
```
 git push --set-upstream origin test  // 当前分支为test 
```

## 4. 把本地的某个分支提交到远程某个分支
```
git ps origin test:test  // 把本地的test提交到远程test
```

## 5. 把远程分支拉到本地
```
git checkout origin/remoteName -b localName
```

## 6. 删除远程一个分支
```
 git push origin :wei   // 删除远程分支wei
```

## 7. Git add 撤销
执行了Git add之后想撤销，让它从暂存区移到工作区
```
git reset --mixed 
```
-- hard 会撤销上一次修改，本地修改的文件会被还原
-- soft
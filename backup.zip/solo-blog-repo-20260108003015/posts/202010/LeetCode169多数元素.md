title: LeetCode-169-多数元素
date: '2020-10-27 20:08:20'
updated: '2020-10-27 20:08:20'
tags: [LeetCode, 位运算]
permalink: /articles/2020/10/27/1603800500838.html
---
# 题目描述

```java
给定一个大小为 n 的数组，找到其中的多数元素。多数元素是指在数组中出现次数大于 ⌊ n/2 ⌋ 的元素。

你可以假设数组是非空的，并且给定的数组总是存在多数元素。

 

示例 1:

输入: [3,2,3]
输出: 3
示例 2:

输入: [2,2,1,1,1,2,2]
输出: 2
```

# 解法

## 摩尔投票法

思路：

候选人(cand_num)初始化为nums[0]，票数count初始化为1。
当遇到与cand_num相同的数，则票数count = count + 1，否则票数count = count - 1。
当票数count为0时，更换候选人，并将票数count重置为1。
遍历完数组后，cand_num即为最终答案。

go代码如下：

```
func majorityElement(nums []int) int {

	/**
	  *	摩尔投票法
	 */
	var count  = 1
	var base = nums[0]
	for i:=1; i<len(nums); i++ {

		if base == nums[i] {
			count += 1
		} else if count <= 0 && base != nums[i] {
			base = nums[i]
			count = 1
		} else if base != nums[i] {
			count -= 1
		}
	}

	return base
}
```

运行结果为：

![image.png](https://b3logfile.com/file/2020/10/image-3b78de71.png)

## 先排序再求解

因为总是存在多数元素，所以排序后大于1/2的数字是多数数字

```
func majorityElement(nums []int) int {
	sort.Ints(nums)
	return nums[len(nums) / 2]
}
```

涉及到排序，效率比较低

运行结果如下：

![image.png](https://b3logfile.com/file/2020/10/image-76992d90.png)

## 哈希表

维护一个哈希表，记录出现的次数，次数最多的就是多数元素，很简单，代码略

## 位运算

还有一种不错的解法，利用位运算，将这个大多数按位来建立，从0到31位，每次统计下数组中该位上0和1的个数，如果1多，那么将结果 res 中该位变为1，最后累加出来的 res 就是过半数了

Java 代码如下：

```
public int majorityElement(int[] nums) {
        int res = 0;
        int length = nums.length;
        for(int i=0; i<32; i++) {
            int ones = 0;
            int zeros = 0;

            for(int j=0; j<length; j++) {
                if (ones > length / 2 || zeros > length / 2) {
                    break;
                }
                if ((nums[j] & (1 << i)) != 0) {
                    ones++;
                } else {
                    zeros++;
                }
            }
            if(ones > zeros) {
                res |= 1 << i;
            }
        }
        return res;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/10/image-f403752d.png)
title: Mac安装unrar和rar解压缩工具
date: '2017-05-25 21:18:24'
updated: '2017-05-25 21:18:24'
tags: [mac]
permalink: /articles/2017/05/25/1495718300175.html
---
# 前言
今天在mac上要解压一个rar格式的文件，但是mac默认不支持解压rar格式文件。自己捣腾了一番

# 安装过程
>*  进入[rarlab](http://www.rarlab.com/download.htm)下载`RAR 5.50 beta 3 for Mac OS`
>*  打开Mac终端，在文件的同级目录执行解压缩命令：tar xvfz rarosx-5.2.b1.tar进行解压。如果解压不了请使用`sudo`
>*  进入刚刚解压的rar目录中，cd /rar
>*  在rar目录下使用如下命令进行安装 

```
sudo install -c -o$USER unrar usr/local/bin
sudo install -c -o$USER rar usr/local/bin
```

# 解压与压缩
```
unrar x filename.rar             #解压
rar a archivename.rar filename   #压缩
```

# end
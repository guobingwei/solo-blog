title: 几种常见的Agent框架对比
date: '2025-12-25 17:32:40'
updated: '2025-12-25 17:35:22'
tags: [大模型]
permalink: /articles/2025/12/25/1766655160886.html
---
| 框架       | 多 Agent 协作        | 角色分工       | 任务自动化 | 软件工程优化   | 上手难度 | 生产就绪           |
| ------------ | ---------------------- | ---------------- | ------------ | ---------------- | ---------- | -------------------- |
| MetaGPT    | ✅（强）             | ✅（SOP固化）  | ✅         | ✅✅✅（SOTA） | 中高     | 高（MGX版）        |
| AutoGen    | ✅✅✅（灵活）       | ✅（自定义）   | ✅         | 中             | 中高     | 高                 |
| CrewAI     | ✅                   | ✅（YAML配置） | ✅         | 中             | 低       | 中                 |
| AgentVerse | ✅（动态组队）       | ✅             | ✅         | 低             | 中       | 中（偏研究）       |
| LangGraph  | ✅（图编排）         | ⚠️（需自建） | ✅✅✅     | 中             | 中高     | ✅✅✅（生产首选） |
| TaskWeaver | ⚠️（单 Agent为主） | ❌             | ✅✅✅     | 中（代码生成） | 中       | 中                 |
| Swarms     | 强                   |                |            |                |          |                    |

知乎分析：[https://zhuanlan.zhihu.com/p/31830253781](https://zhuanlan.zhihu.com/p/31830253781)| 框架名称

![image.png](https://b3logfile.com/file/2025/12/image-ZgnyqHN.png)

# 学习资料


| **学习角色/流程/协作设计**  | **《The Art of Agent-Oriented Modeling》 +****Google Agent Design Patterns** |
| ----------------------------- | ------------------------------------------------------------------------------ |
| **动手开发 LLM Agent 应用** | **《Hands-On LLMs》 +****言午《Agent 开发复盘》**                            |

# Agents.md

[https://agents.md/](https://agents.md/)

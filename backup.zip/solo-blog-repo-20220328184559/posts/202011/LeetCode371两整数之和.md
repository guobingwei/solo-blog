title: LeetCode-371-两整数之和
date: '2020-11-02 08:29:43'
updated: '2020-11-02 08:29:43'
tags: [LeetCode, 位运算]
permalink: /articles/2020/11/02/1604276983746.html
---
![](https://b3logfile.com/bing/20200530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
不使用运算符 + 和 - ，计算两整数 a 、b 之和。

示例 1:

输入: a = 1, b = 2
输出: 3
示例 2:

输入: a = -2, b = 3
输出: 1
```


# 解法

1. 无进位加法使用**异或运算**计算得出
2. 进位结果使用**与运算**和**移位运算**计算得出
3. 循环此过程，直到进位为 0

非递归写法

```
public int missingNumber(int[] nums) {
        int res = nums.length;
        for(int i = 0; i < nums.length; i++) {
            res = res ^ i ^ nums[i];
        }
        return res;
}
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-b9b3a31e.png)



递归写法：

```
 public int getSum(int a, int b) {
        return b == 0 ? a : getSum(a ^ b, (a & b) << 1);
 }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-bf89e3d8.png)

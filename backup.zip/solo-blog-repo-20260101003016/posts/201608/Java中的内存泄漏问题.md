title: Java中的内存泄漏问题
date: '2016-08-27 10:17:46'
updated: '2016-08-27 10:17:46'
tags: [jvm]
permalink: /articles/2016/08/27/1472264266249.html
---
---

内存泄漏的对象有这么两个特点：
>* 首先，这些对象是可达的，即在有向图中，存在通路可以与其相连
>* 其次，这些对象是无用的，即程序以后不会再使用这些对象

代码如下：
```
Vector v=new Vector(10);
for (int i=1;i<100; i++) {
	Object o=new Object();
	v.add(o);
	// 此时，所有的Object对象都没有被释放，因为变量v引用这些对象
	o=null;	
}
```

画个示意图就是这样子的
![此处输入图片的描述][1]

在这个例子中，我们循环申请Object对象，并将所申请的对象放入一个Vector中，如果我们仅仅释放引用本身，那么Vector仍然引用该对象，所以这个对象对GC来说是不可回收的。因此，如果对象加入到Vector后，还必须从Vector中删除，最简单的方法就是将Vector对象设置为null。

  [1]: http://res.chuang.ba/memory-leak.png
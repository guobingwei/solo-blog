title: zsh + iterm 插件安装
date: '2017-04-01 11:49:18'
updated: '2021-04-23 09:00:46'
tags: [插件]
permalink: /articles/2017/04/01/1491018553401.html
---
## 前言

iterm 默认的主题有点无趣，也没有自动提示。不好用。通过安装插件让iterm丰富起来。

## 安装zsh

使用这个命令可以看到你的系统有几个shell
`cat /etc/shells`
回显是这个

```
/bin/bash
/bin/csh
/bin/ksh
/bin/sh
/bin/tcsh
/bin/zsh
```

有zsh就不用安装了，直接用下面的命令设置默认shell就行
`chsh -s /bin/zsh`
然后直接打开新的terminal就行了

zsh的配置文件在这里：`~/.zshrc`
直接打开没啥东西的，需要用这个oh my zsh来调教：

`sh -c "$(curl -fsSL https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"`

执行命令如果遇到错误 `Failed to connect to raw.githubusercontent.com port 443: Connection refused`

按这个链接处理 [解决homebrew安装curl: (7) Failed to connect to http://raw.githubusercontent.com port 443错误](https://blog.csdn.net/dqchouyang/article/details/106575699 "1")

之后你的 `~/.zshrc`文件里面就有东西了
比如[主题](https://github.com/robbyrussell/oh-my-zsh/wiki/themes)自选

## 更改主题

修改文件 `~/.zshrc`中的 `ZSH_THEME`一行，改成这个

```
ZSH_THEME="agnoster" # (this is one of the fancy ones)
# you might need to install a special Powerline font on your console's host for this to work
# see https://github.com/robbyrussell/oh-my-zsh/wiki/Themes#agnoster

```

重新打开一个terminal就行了
如果没有箭头，只有方框+问号的话，还需要安装powerline
这是一个字体增强的软件，就是往字体库里面新加了一个字体
在github可以直接下载然后执行 `install.sh`来安装👉[Powerline-patched font](https://github.com/powerline/fonts)
一步一步的安装方法参见👉[powerline的文档](https://powerline.readthedocs.org/en/latest/installation/linux.html#font-installation)
然后在你的终端gui设置里面，把字体改成后缀为 `powerline`的字体就行了

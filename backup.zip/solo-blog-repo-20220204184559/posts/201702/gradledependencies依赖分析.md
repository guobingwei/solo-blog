title: gradle dependencies依赖分析
date: '2017-02-23 19:06:22'
updated: '2017-02-23 19:06:22'
tags: [gradle]
permalink: /articles/2017/02/23/1487847982403.html
---
## 遇到的问题
最近在项目中遇到一个问题，因为存在jar包冲突的问题，想要解决一下。但是在解决的时候发现了另一个问题。下面详细道来。
当执行 `gradle build` 的时候报错，提示
```
   What went wrong:
    A problem occurred evaluating root project '110-springboot'.
    > Failed to apply plugin [class 'io.spring.gradle.dependencymanagement.DependencyManagementPlugin']
    > Could not create task of type 'DependencyManagementReportTask'.
```
通过网上查了发现是gradle 3.0 的一个bug，后面的版本中已经解决了。于是我下载了新版本的（gradle 3.4）,发现还是存在问题，应该是本地缓存中还有问题，删了一会没有删干净。于是找了另一个解决办法，在build.gradle中加了这么一句话：
```
classpath "io.spring.gradle:dependency-management-plugin:0.6.1.RELEASE"
```
手动引入这个插件依赖。问题得以解决。

接下来`gradle dependencies`命令可以执行了。

## gradle dependencies分析
当你运行dependencies任务时，这个依赖树会打印出来，依赖树显示了你build脚本声明的顶级依赖和它们的传递依赖：

粘一段我运行时的依赖树：
```
 +--- com.alibaba:fastjson:1.1.43 -> 1.2.7
|    +--- io.netty:netty:3.9.2.Final
|    +--- com.dianping.cat:cat-client:1.5.4 (*)
|    +--- org.unidal.framework:foundation-service:2.7.0 (*)
|    +--- org.codehaus.plexus:plexus-container-default:1.6 (*)
|    +--- org.codehaus.plexus:plexus-classworlds:2.5.1
|    +--- org.apache.xbean:xbean-reflect:3.7
|    +--- org.codehaus.plexus:plexus-utils:3.0.20
|    +--- junit:junit:4.11 (*)
|    +--- org.hamcrest:hamcrest-core:1.3
|    +--- io.netty:netty-all:4.0.24.Final
|    +--- com.dianping.lion:lion-client:0.6.7 (*)
|    +--- org.apache.curator:curator-recipes:2.7.1 (*)
|    +--- org.freemarker:freemarker:2.3.22
|    +--- com.facebook.swift:swift-annotations:0.16.0-mt-20151221.124547-1
|    +--- com.facebook.swift:swift-codec:0.16.0-mt-20151218.091258-4 (*)
|    +--- com.thoughtworks.paranamer:paranamer:2.5.2
|    +--- com.google.code.findbugs:annotations:2.0.3
|    +--- com.facebook.swift:swift-generator:0.16.0-mt-20151222.050944-1 (*)
|    +--- com.facebook.swift:swift-idl-parser:0.16.0-mt-20151222.051729-1 (*)
|    +--- org.antlr:antlr-runtime:3.5 (*)
|    +--- org.antlr:stringtemplate:4.0.2 (*)
|    +--- org.apache.thrift:libthrift:0.8.0 (*)
|    +--- org.apache.httpcomponents:httpclient:4.1.2 -> 4.3.6 (*)
|    +--- org.apache.httpcomponents:httpcore:4.1.3 -> 4.3.3
|    \--- org.xerial.snappy:snappy-java:1.1.1.6
+--- com.dianping.lion:lion-client:0.5.4 -> 0.6.7 (*)
+--- com.dianping.cat:cat-client:1.4.4 -> 1.5.4 (*)
+--- com.dianping:avatar-tracker:2.2.5
+--- com.dianping.mp:mpi-provider-remote:1.0.0
+--- com.meituan.log:scribe-log4j2:1.2.6
|    +--- org.apache.logging.log4j:log4j-api:2.3 -> 2.5
|    +--- org.apache.logging.log4j:log4j-core:2.3 -> 2.5 (*)
|    +--- org.apache.thrift:libthrift:0.8.0 (*)
|    +--- org.apache.thrift:libfb303:0.8.0 (*)
|    +--- com.meituan.inf:xmd-common-log4j2:1.1.1-SNAPSHOT
|    |    +--- org.slf4j:slf4j-api:1.7.2 -> 1.7.13
|    |    +--- org.apache.logging.log4j:log4j-slf4j-impl:2.3 -> 2.5 (*)
|    |    +--- org.apache.logging.log4j:log4j-api:2.3 -> 2.5
|    |    +--- org.apache.logging.log4j:log4j-core:2.3 -> 2.5 (*)
|    |    +--- org.apache.logging.log4j:log4j-1.2-api:2.3 (*)
|    |    \--- com.meituan.mtrace:mtrace:1.1.1 (*)
|    +--- com.fasterxml.jackson.core:jackson-core:2.8.0
|    +--- com.fasterxml.jackson.core:jackson-databind:2.8.0 (*)
|    \--- com.fasterxml.jackson.core:jackson-annotations:2.8.0
+--- com.sankuai.meituan.zcm.pos.officialacounts:zcm-pos-officialacounts:1.0.3-SNAPSHOT
|    +--- com.meituan.service.mobile:mtthrift:1.6.4 (*)
|    \--- javax.validation:validation-api:1.0.0.GA
+--- com.sankuai.meituan.zcm.pos.marketing:zcm-pos-marketing-client:1.0.4-SNAPSHOT
|    +--- com.meituan.service.mobile:mtthrift:1.6.4 (*)
|    \--- javax.validation:validation-api:1.0.0.GA
+--- junit:junit:4.11 (*)
+--- org.springframework.javaconfig:spring-javaconfig:1.0.0.m3
|    +--- org.springframework:spring-core:2.5 -> 4.2.3.RELEASE (*)
|    +--- org.springframework:spring-beans:2.5 -> 4.2.3.RELEASE (*)
|    +--- org.springframework:spring-context:2.5 -> 4.2.3.RELEASE (*)
```
仔细观察你会发现有些传递依赖标注了*号，表示这个依赖被忽略了，这是因为其他顶级依赖中也依赖了这个传递的依赖，Gradle会自动分析下载最合适的依赖。

## Transitive
Transitive用于自动处理子依赖项。默认为true，gradle自动添加子依赖项，形成一个多层树形结构；设置为false，则需要手动添加每个依赖项。

### 案例

```
  dependencies {
  androidTestCompile('com.android.support.test:runner:0.2')
  androidTestCompile('com.android.support.test:rules:0.2')
  androidTestCompile('com.android.support.test.espresso:espresso-core:2.1')
  }
```

运行gradle dependencies的结果如下。可以看到每个包的依赖项都被递归分析并添加进来。
```
1.  `+--- com.android.support.test:runner:0.2`
2.  `|  +--- junit:junit-dep:4.10`
3.  `|  | \--- org.hamcrest:hamcrest-core:1.1`
4.  `|  +--- com.android.support.test:exposed-instrumentation-api-publish:0.2`
5.  `| \--- com.android.support:support-annotations:22.0.0`
6.  `+--- com.android.support.test:rules:0.2`
7.  `| \--- com.android.support.test:runner:0.2  (*)`
8.  `\--- com.android.support.test.espresso:espresso-core:2.1`
9.  `+--- com.android.support.test:rules:0.2  (*)`
10.  `+--- com.squareup:javawriter:2.1.1`
11.  `+--- org.hamcrest:hamcrest-integration:1.1`
12.  `| \--- org.hamcrest:hamcrest-core:1.1`
13.  `+--- com.android.support.test.espresso:espresso-idling-resource:2.1`
14.  `+--- org.hamcrest:hamcrest-library:1.1`
15.  `| \--- org.hamcrest:hamcrest-core:1.1`
16.  `+--- javax.inject:javax.inject:1`
17.  `+--- com.google.code.findbugs:jsr305:2.0.1`
18.  `+--- com.android.support.test:runner:0.2  (*)`
19.  `+--- javax.annotation:javax.annotation-api:1.2`
20.  `\--- org.hamcrest:hamcrest-core:1.1`
```

通过提示就很容易分析jar包冲突的问题了
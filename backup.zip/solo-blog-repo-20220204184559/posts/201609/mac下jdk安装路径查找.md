title: mac下jdk安装路径查找
date: '2016-09-29 16:05:05'
updated: '2016-09-29 16:05:24'
tags: [工作日常]
permalink: /articles/2016/09/29/1475136305052.html
---

今天我要在mac下找jre的路径，然后替换一个包，死活没找到。。查找了一下资料，知道了方法。

mac下jdk路径查找


命令如下：

`/usr/libexec/java_home -V`


然后会打印出安装jdk的路径

` 1.8.0_101, x86_64:	"Java SE 8"	/Library/Java/JavaVirtualMachines/jdk1.8.0_101.jdk/Contents/Home`


jre路径找到了~
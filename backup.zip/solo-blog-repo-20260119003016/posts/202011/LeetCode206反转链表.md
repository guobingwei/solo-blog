title: LeetCode-206-反转链表
date: '2020-11-07 00:26:15'
updated: '2020-11-07 00:26:15'
tags: [LeetCode, 链表]
permalink: /articles/2020/11/07/1604679975730.html
---
![](https://b3logfile.com/bing/20181117.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目

反转一个单链表。

示例:

输入: 1->2->3->4->5->NULL
输出: 5->4->3->2->1->NULL
进阶:
你可以迭代或递归地反转链表。你能否用两种方法解决这道题？

# 解法

## 迭代解法：

```
public ListNode reverseList(ListNode head) {
        ListNode pre = null;
        ListNode current = head;
        while(current != null) {
            ListNode next = current.next;
            current.next = pre;
            pre = current;
            current = next;
        }
        return pre;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-7a66fb76.png)

## 递归解法

* head.next 之下的节点都已经反转好
* head.next.next = head 节点
* head.next 置为null

```
public ListNode reverseList(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        ListNode p = reverseList(head.next);
        head.next.next = head;
        head.next = null;
        return p;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-523bfdfb.png)
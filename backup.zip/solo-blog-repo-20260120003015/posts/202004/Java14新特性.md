title: Java 14 新特性
date: '2020-04-10 00:06:24'
updated: '2020-04-10 00:06:24'
tags: [Java]
permalink: /articles/2020/04/10/1586448384153.html
---
发布了名为Java 14的Java新版本，其中包括许多新功能，工具，安全性，调试和更新的文档方面的改进。 但是，Oracle还向您提供Java的较旧版本，因为它具有向后兼容性，因此您以前的代码仍可以在较旧的版本上运行，并且Java 14的语法与Java 8或9并不是完全不同的，它只是新版本 对前一个进行了一些改进

# 1. switch表达式优化

###  Switch Expression (JEP 361)

一直以来，Java都是使用类C++、C的switch表达式，在Java 12，13中对switch表达式做了一些优化，作为预览版本引入，直到Java14正式引入进来。
让我们来看一下，在Java 14之前如何写switch表达式。
```
tags.switch (day) {
 case 1:
   System.out.println("Let's meet!");
   break;
 case 2:
   break;
 case 3:
   System.out.println("Let's meet!"); 
   break;
 case 4:
   break;
 case 5:
   System.out.println("Let's meet!");
   break;
 case 6: 
   break;
 case 7:
   System.out.println("It's Sunday we cannot meet today");
   break;
  }
```
### Java 14 Switch Expression Arrow Operator
Java 14 中写法

```
case identifier -> statement;
```
或者
```
case identifier -> {// statement block ;}
```

让我们用Java 14的语法来重写上面的例子：
```
switch (day) {
 case 1, 3, 5 -> System.out.println("Let's meet!");
 case 2, 4, 6 -> {
       // Do nothing
 }
 case 7 -> System.out.println("It’s Sunday we cannot meet today");
 default -> "Not valid";
 }
```

### Java 14 Switch Expression yield Operator

使用`yield`关键字，作用类似于`return`

yield Syntax:
```
case -> {yield value;}
```
Switch Expression for Java 14 (yield statement):
```
String message = switch (day) {
 case 1, 3, 5 -> "Let's meet!";
 case 2, 4, 6 -> {
   yield "No meeting today";
 }
 case 7 -> {
   yield "It's Sunday we cannot meet today"; }
 default -> "Not valid";
};
```

# 2. 文本块

### Text Block (JEP, 368):

Java 14之前对于多行字符串的写法，处理换行很麻烦，得加入回车符，多段拼接
```
String old_java = " This is first line\n" + "This is second line" + "and this is third line\n";
```

Java 14的写法，支持文本块
利用``` """ """``` 处理换行
Example:
```
String new_java = """
     This is the first line
     This is Second Line
     and this is the third line
     """;
```

# 3. instanceof 优化

### Java 14 Pattern Matching, for instance (JEP 305)
Java的较早版本中已经存在instanceof语句，但是Java 14提供了一种技术，我们可以使用单行而不是多行将字符串对象类型转换为另一个字符串变量。
Older version of Java with Typecasting using instanceof:
```
Object object_string = "It is a string, but is treated as an object...";
    if (object_string instanceof String)
{
    String stringObject = (String) object_string;
    System.out.println(stringObject.length());
}
```

Java 14
```
Object object_string = "It is a string but it treated as an object...";
    if (object_string instanceof String stringObject)
{
    System.out.println(stringObject.length())
}
```
现在，我们无需为类型转换显式编写额外的语句； Java 14中instanceof语句的增强可以在一行内同时键入新变量的收敛。

# 4. 记录
它是Java 14的预览模式，我们可以期望Java 15中具有完整的标准格式。假设我们想创建某种方式来表示Student详细信息，为此，我们可以创建一个Student类，其中包含一些数据变量，例如 名称，年龄和等级。
```
class Student 
{
  public final String name, grades;
  public final int age;
}
```
但是在这里我们不需要getter和setter。 相反，我们将创建一个构造函数。 创建一个构造函数是一个好习惯，在它的帮助下，我们还可以判断两个Student对象是否引用同一个Student。

```
class Student {
		public final String name, grades;
		public final int age;

		public Student(String name, int age, String grades) {
			this.name = name;
			this.age = age;
			this.grades = grades;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;
			Student student = (Student) o;
			return Objects.equal(student.name, name) == 0 &&
					Objects.equal(student.grades, grades) == 0 &&
					Integer.compare(age, student.age);
		}

		@Override
		public int hashCode() {
			return Objects.hash(name, age, grades);
		}

		@Override
		public String toString() {
			return "Student{" +
					"name=" + latitude +
					", age" + longitude +
					", grades='" + grades + '\'' +
					'}';
		}
	}
```
在上面的代码中，我们主要关注学生的详细信息，即姓名，年龄和年级，但是我们覆盖了诸如构造函数，哈希码，equals和toString之类的方法，但是Java 14提供了可以解析的预览功能记录 这种样板。
```
record Student(String name, int age, String grades){}
```
在这里，构造函数，哈希码，equals和toString将由编译器生成，您可以节省很多不必要的代码重写。

# 5. 空指针优化
### Helpful NullPointer Exceptions(JEP 358)
它是Java 14中已添加的一项新功能。Java虚拟机引发一个异常，称为NullPointerException（NPE），当代码尝试取消引用空引用时，会发生此异常，并且它是其中的一种。 Java中最常见的异常。
```
obj.sec_obj.val = 10;
```

Exception:
```
	Exception in thread "main" java.lang.NullPointerException
	at Npe.main(Npe.java:17)
```
本示例是在较旧版本的Java上编译的，在这里您可以看到错误消息未提供引用为null的任何特定信息，它可以是obj或obj.sec_obj。

但是Java 14解决了这个问题，并提供了更好的错误消息来调试此语句。
```
tags.obj.sec_obj.val = 10;
```

Output:
```
Exception in thread "main" java.lang.NullPointerException:
	Cannot read field "val" because "obj.sec_obj" is null
	at Npe.main(Npe.java:17)
```

# 6. 结语
这是Java 14的一些重要新功能，如果您是Java开发人员，则可以在功能库中添加这些功能，其中一些功能已在Java 14中进行了预览，并且某些功能已正确实现。 Java开发人员社区仍在进行升级，下一个更新中还有许多其他更改。 除了这些功能之外，Java 14还引入了许多其他新功能。建议您转到Java JEP的官方文档并阅读所有官方更新。
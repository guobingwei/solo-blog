title: LeetCode-231-2的幂次方
date: '2020-11-03 23:03:07'
updated: '2020-11-03 23:03:07'
tags: [LeetCode, 位运算]
permalink: /articles/2020/11/03/1604415787278.html
---
![](https://b3logfile.com/bing/20190629.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
给定一个整数，编写一个函数来判断它是否是 2 的幂次方。

示例 1:

输入: 1
输出: true
解释: 20 = 1
示例 2:

输入: 16
输出: true
解释: 24 = 16
示例 3:

输入: 218
输出: false
```


# 解法

思路：2的n次幂有个特点，最高位为1，其他位都是0。2的n次幂-1 最高位为0，其他位都是1，所以两个数做与运算，如果为0，则是2的n次幂

```
public boolean isPowerOfTwo(int n) {
        if (n <= 0) {
            return false;
        }
        return (n & (n - 1)) == 0;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-bdedb249.png)

title: LeedCode-有效的括号
date: '2020-04-12 00:26:08'
updated: '2020-04-12 00:26:08'
tags: [LeedCode]
permalink: /articles/2020/04/12/1586622368159.html
---
# 题目描述

```
给定一个只包括 '('，')'，'{'，'}'，'['，']' 的字符串，判断字符串是否有效。

有效字符串需满足：

左括号必须用相同类型的右括号闭合。
左括号必须以正确的顺序闭合。
注意空字符串可被认为是有效字符串。

示例 1:

输入: "()"
输出: true
示例 2:

输入: "()[]{}"
输出: true
示例 3:

输入: "(]"
输出: false
示例 4:

输入: "([)]"
输出: false
示例 5:

输入: "{[]}"
输出: true

```

# 解法

### 1. 采用Java提供的工具类

利用Java提供的工具类String.contains() 判断是否存在 `{}`, `[]`, `()`，如果存在，利用String.replace() 替换为空字符串

代码如下：

```
public boolean isValid(String s) {
        if (s.length() <= 0) {
		return true;
	}

	while (s.contains("{}") || s.contains("[]") || s.contains("()")) {
		s = s.replace("{}", "");
		s = s.replace("[]", "");
		s = s.replace("()", "");
	}
	return s.equals("");
    }
```

运行结果：

![image.png](https://img.hacpai.com/file/2020/04/image-007a8ee3.png)

可以看到，性能相当差。。。

### 2. 利用栈的特性辅助解决

利用栈First In - Last out 的特性处理

`值得留意的一点，stack是一个线程不安全的栈，推荐使用Deque，功能类似，但是是线程安全的`

优化点：
> * 如果数字为空直接返回
> *  如何字符串长度为奇数，直接返回false

```
public static boolean isValidByStack(String s) {
	if (s.length() <=0) {
		return true;
	}

	if (s.length() % 2 != 0) {
		return false;
	}
	Deque<Character> stack = new ArrayDeque<>();
	for (char c : s.toCharArray()) {
		if ('{' == c) {
			stack.push('}');
		} else if ('(' == c) {
			stack.push(')');
		} else if ('[' == c) {
			stack.push(']');
		} else if (stack.isEmpty() || c != stack.pop()) {
			return false;
		}
	}
	return stack.isEmpty();
}
```

执行结果：
执行耗时：2ms，比之前的暴力解法效率提高了很多
![image.png](https://img.hacpai.com/file/2020/04/image-437b1a1e.png)
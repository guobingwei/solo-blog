title: LeetCode-21-合并两个有序链表
date: '2020-11-06 22:33:13'
updated: '2020-11-06 22:33:13'
tags: [LeetCode, 链表]
permalink: /articles/2020/11/06/1604673193789.html
---
![](https://b3logfile.com/bing/20200905.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 题目描述

```
将两个升序链表合并为一个新的 升序 链表并返回。新链表是通过拼接给定的两个链表的所有节点组成的。 
示例：

输入：1->2->4, 1->3->4
输出：1->1->2->3->4->4
```

# 解法

## 递归

解法如下：

```
 public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        // 递归
        if (l1 == null) {
            return l2;
        }
        if(l2 == null) {
            return l1;
        }
        if(l1.val < l2.val) {
            l1.next = mergeTwoLists(l1.next, l2);
            return l1;
        } else {
            l2.next = mergeTwoLists(l1, l2.next);
            return l2;
        }
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-92af27f9.png)

## 迭代

```
public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummyHead = new ListNode(0);
        ListNode current = dummyHead;
        while(l1 != null && l2 != null) {
            if(l1.val < l2.val) {
                current.next = l1;
                l1 = l1.next;
            } else {
                current.next = l2;
                l2 = l2.next;
            }
            current = current.next;
        }
        if (l1 == null) {
            current.next = l2;
        } else {
            current.next = l1;
        }
        return dummyHead.next;
    }
```

运行结果：

![image.png](https://b3logfile.com/file/2020/11/image-64e1793c.png)
